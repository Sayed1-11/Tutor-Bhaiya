<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/csrf.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/app_layout.php';

$token = $_GET['token'] ?? $_POST['token'] ?? '';
$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $token = $_POST['token'] ?? '';

    if ($new_password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($new_password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        $stmt = mysqli_prepare($conn, "SELECT pr.*, u.username FROM password_resets pr
            JOIN users u ON pr.user_id = u.id
            WHERE pr.token = ? AND pr.expires_at > NOW()");
        mysqli_stmt_bind_param($stmt, 's', $token);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $uid = $row['user_id'];
            $hashed = hashPassword($new_password);

            $upd = mysqli_prepare($conn, "UPDATE users SET password = ? WHERE id = ?");
            mysqli_stmt_bind_param($upd, 'si', $hashed, $uid);
            mysqli_stmt_execute($upd);

            $del = mysqli_prepare($conn, "DELETE FROM password_resets WHERE user_id = ?");
            mysqli_stmt_bind_param($del, 'i', $uid);
            mysqli_stmt_execute($del);

            logActivity($conn, $uid, 'Password reset', "Via token");
            $success = "Password updated. <a href='login.php'>Sign in</a>";
        } else {
            $error = "Invalid or expired reset link.";
        }
    }
}

page_open('Reset Password', 'page-shell', true);
render_public_navbar(false, true, 'login');
?>
<main class="auth-main">
    <div class="auth-box">
        <a href="../index.php" class="auth-logo">Nova AI</a>
        <div class="auth-card">
            <h1>New password</h1>
            <p class="auth-sub">Choose a strong password for your account.</p>
            <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
            <?php else: ?>
                <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
                <form method="POST" action="">
                    <?= csrfField() ?>
                    <input type="hidden" name="token" value="<?= e($token) ?>">
                    <label for="new_password">New password</label>
                    <input type="password" id="new_password" name="new_password" required minlength="6">
                    <label for="confirm_password">Confirm password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required minlength="6">
                    <button type="submit" class="btn btn-block">Update password</button>
                </form>
            <?php endif; ?>
            <div class="auth-links">
                <p><a href="login.php">Back to sign in</a></p>
            </div>
        </div>
    </div>
</main>
<?php auth_page_close(); ?>
