<?php
require_once '../../includes/session.php';
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/security.php';
require_once '../../includes/app_layout.php';

requireLogin();

$stats = [
    'users'    => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM users"))['c'],
    'chats'    => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM chat_messages"))['c'],
    'feedback' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM feedback"))['c'],
    'sessions' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM chat_sessions"))['c'],
    'uploads'  => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM uploads"))['c'],
    'contacts' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM contact_messages"))['c'],
];
$recent_logs = mysqli_query($conn, "SELECT a.*, u.username FROM activity_log a JOIN users u ON a.user_id=u.id ORDER BY a.id DESC LIMIT 10");
$recent_feedback = mysqli_query($conn, "SELECT f.rating, f.created_at, u.username FROM feedback f JOIN users u ON f.user_id=u.id ORDER BY f.id DESC LIMIT 5");

admin_page_open('Dashboard');
render_admin_navbar('dashboard');
?>
<main class="page-main container">
    <div class="dash-banner">
        <div>
            <h2>Admin control panel</h2>
            <p>Monitor users, review feedback, and manage platform activity.</p>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <a href="feedback.php" class="btn btn-sm">Review feedback</a>
            <a href="contacts.php" class="btn btn-sm btn-outline">Contact messages</a>
        </div>
    </div>

    <div class="grid-3" style="margin-bottom:16px;">
        <div class="stat-card"><div class="num"><?= (int)$stats['users'] ?></div><div class="label">Total users</div></div>
        <div class="stat-card"><div class="num"><?= (int)$stats['chats'] ?></div><div class="label">Chat messages</div></div>
        <div class="stat-card"><div class="num"><?= (int)$stats['feedback'] ?></div><div class="label">Feedback items</div></div>
    </div>
    <div class="grid-3" style="margin-bottom:32px;">
        <div class="stat-card"><div class="num"><?= (int)$stats['sessions'] ?></div><div class="label">Chat sessions</div></div>
        <div class="stat-card"><div class="num"><?= (int)$stats['uploads'] ?></div><div class="label">File uploads</div></div>
        <div class="stat-card"><div class="num"><?= (int)$stats['contacts'] ?></div><div class="label">Contact messages</div></div>
    </div>

    <div class="quick-action-grid" style="margin-bottom:32px;max-width:600px;">
        <a href="users.php" class="quick-action-card"><span class="qa-icon qa-dir">Us</span><span class="qa-icon-label">Users</span></a>
        <a href="feedback.php" class="quick-action-card"><span class="qa-icon qa-fb">Fb</span><span class="qa-icon-label">Feedback</span></a>
        <a href="contacts.php" class="quick-action-card"><span class="qa-icon qa-res">Ct</span><span class="qa-icon-label">Contacts</span></a>
        <a href="logs.php" class="quick-action-card"><span class="qa-icon qa-search">Lg</span><span class="qa-icon-label">Activity log</span></a>
        <a href="settings.php" class="quick-action-card"><span class="qa-icon qa-res">St</span><span class="qa-icon-label">Settings</span></a>
    </div>

    <div class="grid-2">
        <div class="card">
            <h2 style="font-size:18px;color:#94a3b8;margin-bottom:16px;">Recent activity</h2>
            <table>
                <thead><tr><th>User</th><th>Action</th><th>Time</th></tr></thead>
                <tbody>
                    <?php while ($log = mysqli_fetch_assoc($recent_logs)): ?>
                    <tr><td><?= e($log['username']) ?></td><td><?= e($log['action']) ?></td><td><?= e($log['created_at']) ?></td></tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <div class="card">
            <h2 style="font-size:18px;color:#94a3b8;margin-bottom:16px;">Latest feedback</h2>
            <table>
                <thead><tr><th>User</th><th>Rating</th><th>Date</th></tr></thead>
                <tbody>
                    <?php if ($recent_feedback): while ($f = mysqli_fetch_assoc($recent_feedback)): ?>
                    <tr><td><?= e($f['username']) ?></td><td><?= str_repeat('★', (int)$f['rating']) ?></td><td><?= e($f['created_at']) ?></td></tr>
                    <?php endwhile; else: ?>
                    <tr><td colspan="3" style="color:#64748b;">No feedback yet</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <a href="feedback.php" style="display:inline-block;margin-top:14px;font-size:14px;">View all feedback →</a>
        </div>
    </div>
</main>
<?php admin_page_close(); ?>
