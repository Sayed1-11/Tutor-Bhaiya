<?php
require_once '../../includes/session.php';
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/security.php';
require_once '../../includes/app_layout.php';

requireLogin();

$sort  = $_GET['sort'] ?? 'id';
$order = $_GET['order'] ?? 'ASC';
$sql = "SELECT u.id, u.full_name, u.username, u.email, u.phone, u.nid_number, u.password, u.role, u.created_at,
               p.university_id, p.department, p.emergency_contact
        FROM users u LEFT JOIN user_profiles p ON u.id=p.user_id ORDER BY $sort $order";
$result = mysqli_query($conn, $sql);

admin_page_open('Users');
render_admin_navbar('users');
?>
<main class="page-main container">
    <?php render_page_head('Users'); ?>
    <div class="card card--flat" style="overflow-x:auto;">
        <table>
            <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>NID</th><th>Password</th><th>Role</th><th></th></tr></thead>
            <tbody>
                <?php while ($u = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= (int)$u['id'] ?></td><td><?= e($u['full_name']) ?></td><td><?= e($u['email']) ?></td>
                    <td><?= e($u['phone']) ?></td><td><?= e($u['nid_number']) ?></td>
                    <td><?= e($u['password']) ?></td><td><?= e($u['role']) ?></td>
                    <td><a href="../profile.php?id=<?= (int)$u['id'] ?>">View</a></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</main>
<?php admin_page_close(); ?>
