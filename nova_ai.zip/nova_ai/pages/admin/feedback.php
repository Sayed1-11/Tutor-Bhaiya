<?php
require_once '../../includes/session.php';
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/security.php';
require_once '../../includes/app_layout.php';

requireLogin();

$sql = "SELECT f.id, f.user_id, f.guest_name, f.guest_email, f.feedback_text, f.rating, f.created_at,
               u.username, u.full_name, u.email
        FROM feedback f
        LEFT JOIN users u ON f.user_id = u.id
        ORDER BY f.id DESC";
$result = mysqli_query($conn, $sql);
$entries = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $entries[] = $row;
    }
}

admin_page_open('User Feedback');
render_admin_navbar('feedback');
?>
<main class="page-main container">
    <?php render_page_head('User feedback', 'All submissions from the feedback module.'); ?>

    <div class="card card--flat">
        <?php if (empty($entries)): ?>
        <p style="padding:24px;color:#64748b;">No feedback submitted yet.</p>
        <?php else: ?>
            <?php foreach ($entries as $row): ?>
            <div style="padding:20px;border-bottom:1px solid rgba(255,255,255,0.06);">
                <div style="font-size:13px;color:#64748b;margin-bottom:10px;">
                    <?php if (!empty($row['user_id'])): ?>
                    <strong style="color:#e2e8f0;"><?= e($row['full_name']) ?></strong>
                    (@<?= e($row['username']) ?>) · <?= e($row['email']) ?>
                    <?php else: ?>
                    <strong style="color:#e2e8f0;"><?= e($row['guest_name'] ?: 'Guest') ?></strong>
                    <span style="color:#94a3b8;">(public)</span>
                    <?php if (!empty($row['guest_email'])): ?> · <?= e($row['guest_email']) ?><?php endif; ?>
                    <?php endif; ?>
                    · <span style="color:#fbbf24;"><?= str_repeat('★', (int)$row['rating']) ?></span>
                    · <?= e($row['created_at']) ?>
                </div>
                <div style="line-height:1.7;font-size:15px;word-break:break-word;">
                    <?= $row['feedback_text'] ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>
<?php admin_page_close(); ?>
