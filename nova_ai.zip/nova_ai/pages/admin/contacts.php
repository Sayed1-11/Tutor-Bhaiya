<?php
require_once '../../includes/session.php';
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/security.php';
require_once '../../includes/app_layout.php';

requireLogin();

$sql = "SELECT id, name, email, phone, message, created_at
        FROM contact_messages
        ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
$entries = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $entries[] = $row;
    }
}
$total = count($entries);

admin_page_open('Contact Messages');
render_admin_navbar('contacts');
?>
<main class="page-main container">
    <?php render_page_head('Contact messages', 'All submissions from the public contact form.'); ?>

    <div class="grid-3" style="margin-bottom:24px;max-width:320px;">
        <div class="stat-card">
            <div class="num"><?= $total ?></div>
            <div class="label">Total messages</div>
        </div>
    </div>

    <div class="card card--flat" style="overflow-x:auto;">
        <?php if (empty($entries)): ?>
        <p style="padding:24px;color:#64748b;">No contact messages yet.</p>
        <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Message</th>
                    <th>Submitted</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($entries as $row): ?>
                <tr>
                    <td><?= (int)$row['id'] ?></td>
                    <td><?= e($row['name']) ?></td>
                    <td><?= e($row['email']) ?></td>
                    <td><?= e($row['phone'] ?: '—') ?></td>
                    <td style="max-width:320px;word-break:break-word;"><?= e($row['message']) ?></td>
                    <td style="white-space:nowrap;"><?= e($row['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</main>
<?php admin_page_close(); ?>
