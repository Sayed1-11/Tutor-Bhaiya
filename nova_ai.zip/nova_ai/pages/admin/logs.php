<?php
require_once '../../includes/session.php';
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/security.php';
require_once '../../includes/app_layout.php';

requireLogin();

$logs = mysqli_query($conn, "SELECT a.*, u.username FROM activity_log a JOIN users u ON a.user_id=u.id ORDER BY a.id DESC LIMIT 100");

admin_page_open('Activity Log');
render_admin_navbar('logs');
?>
<main class="page-main container">
    <?php render_page_head('Activity log'); ?>
    <div class="card card--flat" style="overflow-x:auto;">
        <table>
            <thead><tr><th>User</th><th>Action</th><th>Details</th><th>IP</th><th>Time</th></tr></thead>
            <tbody>
                <?php while ($l = mysqli_fetch_assoc($logs)): ?>
                <tr><td><?= e($l['username']) ?></td><td><?= e($l['action']) ?></td><td><?= e($l['details']) ?></td><td><?= e($l['ip_address']) ?></td><td><?= e($l['created_at']) ?></td></tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</main>
<?php admin_page_close(); ?>
