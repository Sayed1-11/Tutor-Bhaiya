<?php
require_once '../../includes/session.php';
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/csrf.php';
require_once '../../includes/security.php';
require_once '../../includes/app_layout.php';

requireLogin();

$success = "";
$settings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin_settings LIMIT 1"));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $site_name = trim($_POST['site_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $api_key = trim($_POST['api_key'] ?? '');
    $stmt = mysqli_prepare($conn, "UPDATE admin_settings SET site_name = ?, email = ?, api_key = ? WHERE id = 1");
    mysqli_stmt_bind_param($stmt, 'sss', $site_name, $email, $api_key);
    if (mysqli_stmt_execute($stmt)) {
        $success = "Settings saved.";
        $settings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin_settings LIMIT 1"));
    }
}

admin_page_open('Settings');
render_admin_navbar('settings');
?>
<main class="page-main container page-main--narrow">
    <?php render_page_head('Settings'); ?>
    <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
    <form method="POST" class="card">
        <?= csrfField() ?>
        <label>Site name</label><input type="text" name="site_name" value="<?= e($settings['site_name'] ?? '') ?>">
        <label>Contact email</label><input type="email" name="email" value="<?= e($settings['email'] ?? '') ?>">
        <label>API key</label><input type="text" name="api_key" value="<?= e($settings['api_key'] ?? '') ?>">
        <button type="submit" class="btn">Save</button>
    </form>
</main>
<?php admin_page_close(); ?>
