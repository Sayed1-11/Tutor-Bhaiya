<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';

requireLogin();

$user_id = (int)$_SESSION['user_id'];
$keyword = trim($_GET['q'] ?? '');
$results = [];

if ($keyword !== '') {
    $escaped = mysqli_real_escape_string($conn, $keyword);
    $like = "%{$escaped}%";

    $res1 = mysqli_query($conn, "SELECT id, user_message, bot_response, created_at
        FROM chat_messages
        WHERE user_id = $user_id AND (user_message LIKE '$like' OR bot_response LIKE '$like')
        ORDER BY id DESC LIMIT 20");
    if ($res1) {
        while ($row = mysqli_fetch_assoc($res1)) {
            $row['source'] = 'conversation';
            $results[] = $row;
        }
    }

    $res2 = mysqli_query($conn, "SELECT id, content, role, created_at
        FROM chat_history
        WHERE user_id = $user_id AND content LIKE '$like'
        ORDER BY id DESC LIMIT 20");
    if ($res2) {
        while ($row = mysqli_fetch_assoc($res2)) {
            $results[] = [
                'content' => $row['content'],
                'role' => $row['role'],
                'created_at' => $row['created_at'],
                'source' => 'session',
            ];
        }
    }

    usort($results, fn($a, $b) => strcmp($b['created_at'], $a['created_at']));
    $results = array_slice($results, 0, 30);
}

page_open('Search Chat History');
render_user_navbar('search_chat');
?>
<main class="page-main container page-main--medium">
    <?php render_page_head('Search chat history', 'Find past messages and AI replies across your conversations.'); ?>

    <form method="GET" class="card form-row">
        <input type="text" name="q" value="<?= e($keyword) ?>" placeholder="Search messages…" autofocus>
        <button type="submit" class="btn">Search</button>
    </form>

    <?php if ($keyword !== ''): ?>
    <p style="margin:20px 0;color:#94a3b8;font-size:16px;">
        <?= count($results) ?> result(s) for
        <strong><?= $keyword ?></strong>
    </p>

    <div class="card card--flat">
        <?php if (empty($results)): ?>
        <p style="padding:24px;color:#64748b;">No messages matched your search.</p>
        <?php else: ?>
            <?php foreach ($results as $hit): ?>
            <div style="padding:16px 20px;border-bottom:1px solid rgba(255,255,255,0.06);">
                <div style="font-size:12px;color:#64748b;margin-bottom:8px;"><?= e($hit['created_at']) ?> · <?= e($hit['source'] ?? 'message') ?></div>
                <?php if (($hit['source'] ?? '') === 'conversation'): ?>
                <div style="font-size:14px;line-height:1.6;"><?= e($hit['user_message'] ?? '') ?></div>
                <?php if (!empty($hit['bot_response'])): ?>
                <div style="font-size:14px;color:#94a3b8;margin-top:6px;">Nova AI: <?= e($hit['bot_response']) ?></div>
                <?php endif; ?>
                <?php else: ?>
                <div style="font-size:14px;line-height:1.6;"><?= e($hit['content'] ?? '') ?> <span style="color:#64748b;">(<?= e($hit['role'] ?? '') ?>)</span></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</main>
<?php page_close(); ?>
