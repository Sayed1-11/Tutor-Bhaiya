<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/app_layout.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password' LIMIT 1";
    $result = mysqli_query($conn, $sql);

    if ($result === false) {
        $error = mysqli_error($conn);
    } elseif (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        session_regenerate_id(true);
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];

        $token = bin2hex(random_bytes(16));
        $ip = getClientIP();
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $sess = mysqli_prepare($conn, "INSERT INTO user_sessions (user_id, token, ip_address, user_agent) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($sess, 'isss', $user['id'], $token, $ip, $ua);
        mysqli_stmt_execute($sess);

        logActivity($conn, $user['id'], 'User logged in', "IP: $ip");

        header("Location: " . ($user['role'] === 'admin' ? 'admin/dashboard.php' : 'chat.php'));
        exit;
    } else {
        $error = "Invalid username or password.";
    }
}

page_open('Sign In', 'page-shell', true);
render_public_navbar(false, true, 'login');
?>
<main class="auth-main">
    <div class="auth-box">
        <a href="../index.php" class="auth-logo">Nova AI</a>
        <div class="auth-card">
            <h1>Sign in</h1>
            <p class="auth-sub">Welcome back — enter your credentials to continue.</p>
            <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
            <form method="POST" action="">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="e.g. rayhan" autocomplete="username" required>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" autocomplete="current-password" required>
                <button type="submit" class="btn btn-block">Sign in</button>
            </form>
            <div class="auth-links">
                <p><a href="forgot_password.php">Forgot password?</a></p>
                <p>Don't have an account? <a href="register.php">Create account</a></p>
            </div>
        </div>
    </div>
</main>
<?php auth_page_close(); ?>
