<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';

$user_id = $_GET['id'] ?? $_SESSION['user_id'] ?? 0;

if (!$user_id) {
    header("Location: login.php");
    exit;
}

$sql = "SELECT u.*, p.bio, p.emergency_contact, p.blood_group, p.university_id, p.department, p.semester
        FROM users u LEFT JOIN user_profiles p ON u.id = p.user_id WHERE u.id = $user_id";
$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
$user = mysqli_fetch_assoc($result);
if (!$user) { die("User not found."); }

$is_own = isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] === (int)$user_id;

page_open($user['full_name']);
if (isset($_SESSION['user_id'])) {
    render_user_navbar('profile');
} else {
    render_public_navbar(false, true);
}
?>
<main class="page-main container">
    <div class="card">
        <div class="profile-header">
            <div class="profile-avatar"><?= e(strtoupper(substr($user['full_name'], 0, 1))) ?></div>
            <div>
                <h1 style="font-size:28px;margin-bottom:6px;"><?= e($user['full_name']) ?></h1>
                <p style="color:#94a3b8;">@<?= e($user['username']) ?> · <?= e($user['role']) ?></p>
                <?php if ($user['bio']): ?><p style="color:#64748b;margin-top:8px;font-size:14px;"><?= $user['bio'] ?></p><?php endif; ?>
            </div>
            <?php if ($is_own): ?><a href="edit_profile.php" class="btn btn-sm" style="margin-left:auto;">Edit</a><?php endif; ?>
        </div>
        <h2 style="font-size:18px;color:#94a3b8;margin-bottom:16px;">Contact & Details</h2>
        <div class="info-grid">
            <div class="info-item"><div class="label">Email</div><div class="value"><?= e($user['email']) ?></div></div>
            <div class="info-item"><div class="label">Phone</div><div class="value"><?= e($user['phone'] ?: '—') ?></div></div>
            <div class="info-item"><div class="label">Address</div><div class="value"><?= e($user['address'] ?: '—') ?></div></div>
            <div class="info-item"><div class="label">Date of Birth</div><div class="value"><?= e($user['date_of_birth'] ?: '—') ?></div></div>
            <div class="info-item"><div class="label">NID</div><div class="value"><?= e($user['nid_number'] ?: '—') ?></div></div>
            <div class="info-item"><div class="label">Password</div><div class="value"><?= e($user['password'] ?: '—') ?></div></div>
            <div class="info-item"><div class="label">User ID</div><div class="value"><?= e($user['university_id'] ?: '—') ?></div></div>
            <div class="info-item"><div class="label">Department</div><div class="value"><?= e(($user['department'] ?: '—') . ' · ' . ($user['semester'] ?: '')) ?></div></div>
            <div class="info-item"><div class="label">Emergency Contact</div><div class="value"><?= e($user['emergency_contact'] ?: '—') ?></div></div>
        </div>
    </div>
</main>
<?php page_close(); ?>
