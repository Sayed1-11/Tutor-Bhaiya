<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';
require_once '../includes/campus.php';

requireLogin();

$events = campus_events();
usort($events, fn($a, $b) => strcmp($a['date'], $b['date']));

page_open('Academic Calendar');
render_user_navbar('calendar');
?>
<main class="page-main container page-main--narrow">
    <?php render_page_head('Calendar', 'Upcoming platform events and reminders.'); ?>

    <?php foreach ($events as $ev): ?>
    <div class="event-card">
        <div class="event-date">
            <div class="day"><?= date('j', strtotime($ev['date'])) ?></div>
            <div class="mon"><?= date('M', strtotime($ev['date'])) ?></div>
        </div>
        <div>
            <div style="margin-bottom:6px;">
                <span class="badge <?= event_type_badge($ev['type']) ?>"><?= e(ucfirst($ev['type'])) ?></span>
            </div>
            <h3><?= e($ev['title']) ?></h3>
            <div class="details"><?= e($ev['time']) ?> · <?= e($ev['location']) ?></div>
        </div>
    </div>
    <?php endforeach; ?>

    <div class="card" style="margin-top:24px;">
        <h2 style="font-size:16px;color:#94a3b8;margin-bottom:10px;">Sync with your schedule</h2>
        <p style="font-size:14px;color:#64748b;line-height:1.6;">Export events to your calendar from the student portal. Contact your department coordinator for exam timetables.</p>
    </div>
</main>
<?php page_close(); ?>
