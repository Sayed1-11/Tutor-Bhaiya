<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';

requireLogin();

$search = $_GET['q'] ?? '';
$results = [];
$query_error = '';

if ($search !== '') {
    $sql = "SELECT u.id, u.full_name, u.username, u.email, u.phone, u.role, u.date_of_birth,
                   p.university_id, p.department
            FROM users u LEFT JOIN user_profiles p ON u.id = p.user_id
            WHERE u.full_name LIKE '%$search%' OR u.username LIKE '%$search%'
               OR u.email LIKE '%$search%' OR u.phone LIKE '%$search%'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) $results[] = $row;
    } else {
        $query_error = mysqli_error($conn);
    }
}

page_open('Directory');
render_user_navbar('directory');
?>
<main class="page-main container">
    <?php render_page_head('Directory', 'Search students and staff by name, username, email, or phone.'); ?>
    <form method="GET" class="card form-row">
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search…">
        <button type="submit" class="btn">Search</button>
    </form>
    <?php if ($query_error): ?>
    <div class="alert alert-error" style="margin-top:20px;"><?= $query_error ?></div>
    <?php endif; ?>
    <?php if ($search !== '' && !$query_error): ?>
    <p style="margin:20px 0;color:#94a3b8;"><?= count($results) ?> result(s) for <?= $search ?></p>
    <?php endif; ?>
    <?php if (!empty($results)): ?>
    <div class="card card--flat" style="overflow-x:auto;">
        <table>
            <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Dept</th><th></th></tr></thead>
            <tbody>
                <?php foreach ($results as $u): ?>
                <tr>
                    <td><?= e($u['full_name']) ?></td><td><?= e($u['email']) ?></td><td><?= e($u['phone']) ?></td>
                    <td><?= e($u['department']) ?></td>
                    <td><a href="profile.php?id=<?= (int)$u['id'] ?>">View</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php elseif ($search !== '' && !$query_error): ?>
    <div class="alert alert-info">No results found.</div>
    <?php endif; ?>
</main>
<?php page_close(); ?>
