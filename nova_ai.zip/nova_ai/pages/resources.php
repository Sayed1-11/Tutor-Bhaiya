<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';
require_once '../includes/campus.php';

requireLogin();

$resources = campus_resources();

page_open('Resources');
render_user_navbar('resources');
?>
<main class="page-main container">
    <?php render_page_head('Resources', 'Tools and features available on Nova AI.'); ?>

    <div class="feature-grid">
        <?php foreach ($resources as $r): ?>
        <div class="icon-card">
            <div class="icon"><?= e(strtoupper(substr($r['title'], 0, 1))) ?></div>
            <h3><?= e($r['title']) ?></h3>
            <p><?= e($r['desc']) ?></p>
            <a href="<?= e($r['link']) ?>">Open →</a>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="card" style="margin-top:40px;">
        <h2 style="font-size:18px;color:#94a3b8;margin-bottom:16px;">Need help?</h2>
        <p style="color:#64748b;font-size:14px;line-height:1.7;margin-bottom:16px;">Visit the IT helpdesk weekdays 9 AM – 5 PM, or submit a ticket through Feedback.</p>
        <a href="contact.php" class="btn btn-sm">Contact support</a>
        <a href="feedback.php" class="btn btn-sm btn-outline" style="margin-left:8px;">Send feedback</a>
    </div>
</main>
<?php page_close(); ?>
