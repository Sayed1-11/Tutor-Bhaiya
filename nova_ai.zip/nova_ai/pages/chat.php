<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/csrf.php';
require_once '../includes/security.php';

requireLogin();
$user_id = (int)$_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chat — Nova AI</title>
<?= csrfMeta() ?>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/chat.css">
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
</head>
<body class="chat-shell">

<button type="button" class="chat-mobile-toggle" id="sidebarToggle" aria-label="Menu">☰</button>
<div class="chat-sidebar-overlay" id="sidebarOverlay"></div>

<div class="chat-layout">
    <aside class="chat-sidebar" id="chatSidebar">
        <div class="chat-sidebar-head">
            <a href="dashboard.php" class="chat-brand">
                <div class="chat-brand-icon">AI</div>
                <span>Nova AI</span>
            </a>
            <button type="button" class="new-chat-btn" onclick="newSession()">+ New chat</button>
        </div>
        <div class="chat-sidebar-body">
            <h3>Recent</h3>
            <div id="sessionList"></div>
        </div>
        <div class="chat-sidebar-foot">
            <a href="dashboard.php">Home</a>
            <a href="profile.php?id=<?= $user_id ?>">Profile</a>
            <a href="logout.php">Logout</a>
        </div>
    </aside>

    <div class="chat-main">
        <div class="chat-messages" id="chatArea">
            <div class="chat-messages-inner" id="chatMessagesInner">
                <div class="chat-welcome" id="chatWelcome">
                    <div class="chat-welcome-icon">AI</div>
                    <h2>How can I help?</h2>
                    <p>Ask me anything — I can write, explain, code, and analyze images you upload.</p>
                    <div class="chat-suggestions">
                        <button type="button" class="chat-suggestion" onclick="useSuggestion('Explain how neural networks work simply')"><strong>Explain a topic</strong>Break down complex ideas</button>
                        <button type="button" class="chat-suggestion" onclick="useSuggestion('Write a Python script to read a CSV file')"><strong>Write code</strong>Get working code snippets</button>
                        <button type="button" class="chat-suggestion" onclick="useSuggestion('আমাকে একটি ছোট গল্প লেখো')"><strong>বাংলায় চ্যাট</strong>বাংলায় প্রশ্ন করুন</button>
                        <button type="button" class="chat-suggestion" onclick="document.getElementById('imageInput').click()"><strong>Upload image</strong>Analyze photos & screenshots</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="chat-composer">
            <div class="chat-composer-inner">
                <div id="imagePreview" class="chat-preview"></div>
                <form id="chatForm">
                    <div class="chat-input-box">
                        <input type="file" id="imageInput" accept="image/*" style="display:none" onchange="previewImage(this)">
                        <button type="button" class="chat-icon-btn" onclick="document.getElementById('imageInput').click()" title="Upload image" aria-label="Upload image">
                            <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                        </button>
                        <button type="button" class="chat-icon-btn" id="voiceBtn" onclick="toggleVoice()" title="Voice input" aria-label="Voice input">
                            <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
                        </button>
                        <textarea id="messageInput" rows="1" placeholder="Message Nova AI…" autocomplete="off"></textarea>
                        <button type="submit" class="chat-send-btn" id="sendBtn" title="Send" aria-label="Send">
                            <svg viewBox="0 0 24 24" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
                        </button>
                    </div>
                </form>
                <p class="chat-disclaimer">Nova AI can make mistakes. Verify important information.</p>
            </div>
        </div>
    </div>
</div>

<script>window.NOVA_CHAT_API = <?= json_encode(rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/api/chat_api.php') ?>;</script>
<script src="../assets/js/chat.js?v=6"></script>
<script>
(function(){
    var toggle = document.getElementById('sidebarToggle');
    var sidebar = document.getElementById('chatSidebar');
    var overlay = document.getElementById('sidebarOverlay');
    function closeSb(){ sidebar.classList.remove('open'); overlay.classList.remove('open'); }
    if (toggle) toggle.onclick = function(){ sidebar.classList.toggle('open'); overlay.classList.toggle('open'); };
    if (overlay) overlay.onclick = closeSb;

    var sid = sessionStorage.getItem('loadSession');
    if (sid) { sessionStorage.removeItem('loadSession'); loadSession(parseInt(sid, 10)); }
})();
</script>
</body>
</html>
