<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';
require_once '../includes/campus.php';

$loggedIn = isset($_SESSION['user_id']);

page_open('About');
render_public_navbar($loggedIn, true);
?>
<main class="page-main container">
    <?php render_page_head('About Nova AI', 'Intelligent assistant powered by GitHub Models.'); ?>

    <div class="grid-3" style="margin-bottom:48px;">
        <div class="stat-card"><div class="num">2024</div><div class="label">Platform launched</div></div>
        <div class="stat-card"><div class="num">2.4K+</div><div class="label">Registered users</div></div>
        <div class="stat-card"><div class="num">12</div><div class="label">Departments</div></div>
    </div>

    <div class="section-title" style="margin-bottom:32px;">
        <h2>What we offer</h2>
    </div>
    <div class="feature-grid" style="margin-bottom:48px;">
        <?php foreach (campus_services() as $s): ?>
        <div class="icon-card">
            <div class="icon qa-icon <?= e($s['color'] ?? 'qa-chat') ?>"><?= e($s['icon'] ?? substr($s['title'], 0, 2)) ?></div>
            <h3><?= e($s['title']) ?></h3>
            <p><?= e($s['desc']) ?></p>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <h2 style="font-size:20px;margin-bottom:12px;">Our mission</h2>
        <p style="color:#94a3b8;line-height:1.8;font-size:15px;">
            Nova AI is a ChatGPT-style assistant that uses GitHub Models for smart conversations,
            image understanding, and voice interaction. Built for everyone who needs a reliable AI helper.
        </p>
        <div style="margin-top:24px;">
            <?php if ($loggedIn): ?>
            <a href="dashboard.php" class="btn btn-sm">Go to dashboard</a>
            <?php else: ?>
            <a href="register.php" class="btn btn-sm">Create account</a>
            <a href="login.php" class="btn btn-sm btn-outline" style="margin-left:8px;">Sign in</a>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php page_close(); ?>
