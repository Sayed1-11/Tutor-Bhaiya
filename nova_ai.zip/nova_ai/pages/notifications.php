<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';

requireLogin();

$stmt = mysqli_prepare($conn, "SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC");
mysqli_stmt_bind_param($stmt, 'i', $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

page_open('Notifications');
render_user_navbar('notifications');
?>
<main class="page-main container page-main--narrow">
    <?php render_page_head('Alerts', 'Your personal notifications and account updates.'); ?>
    <?php if (!$result || !mysqli_num_rows($result)): ?>
    <div class="card"><p style="color:#64748b;">No notifications yet.</p></div>
    <?php else: ?>
        <?php while ($n = mysqli_fetch_assoc($result)): ?>
        <div class="card card--tight">
            <h3 style="font-size:16px;margin-bottom:6px;"><?= e($n['title']) ?></h3>
            <p style="font-size:14px;color:#64748b;"><?= e($n['message']) ?></p>
            <small style="color:#475569;"><?= e($n['created_at']) ?></small>
        </div>
        <?php endwhile; ?>
    <?php endif; ?>
</main>
<?php page_close(); ?>
