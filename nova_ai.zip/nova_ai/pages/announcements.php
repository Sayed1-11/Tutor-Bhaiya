<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';
require_once '../includes/campus.php';

requireLogin();

$items = campus_announcements();
$filter = $_GET['tag'] ?? 'all';
if ($filter !== 'all') {
    $items = array_values(array_filter($items, fn($a) => strtolower($a['tag']) === strtolower($filter)));
}

page_open('Announcements');
render_user_navbar('news');
?>
<main class="page-main container">
    <?php render_page_head('News', 'Platform news and updates.'); ?>

    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:28px;">
        <a href="announcements.php" class="btn btn-sm <?= $filter === 'all' ? '' : 'btn-outline' ?>">All</a>
        <?php foreach (['Academic', 'Platform', 'Campus', 'Career', 'Security'] as $tag): ?>
        <a href="announcements.php?tag=<?= urlencode($tag) ?>" class="btn btn-sm <?= strtolower($filter) === strtolower($tag) ? '' : 'btn-outline' ?>"><?= e($tag) ?></a>
        <?php endforeach; ?>
    </div>

    <?php foreach ($items as $a): ?>
    <article class="announcement-card <?= $a['priority'] === 'high' ? 'priority-high' : '' ?>">
        <div class="meta">
            <span class="tag-pill"><?= e($a['tag']) ?></span>
            <span><?= format_campus_date($a['date']) ?></span>
            <?php if ($a['priority'] === 'high'): ?><span class="badge badge-admin">Important</span><?php endif; ?>
        </div>
        <h3><?= e($a['title']) ?></h3>
        <p><?= e($a['body']) ?></p>
    </article>
    <?php endforeach; ?>
</main>
<?php page_close(); ?>
