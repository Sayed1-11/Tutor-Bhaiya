<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
ensureFeedbackGuestColumns($conn);
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/app_layout.php';

$loggedIn = isset($_SESSION['user_id']);
$user_id  = $loggedIn ? (int)$_SESSION['user_id'] : 0;
$success  = '';
$error    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $feedback    = $_POST['feedback_text'] ?? '';
    $rating      = max(1, min(5, (int)($_POST['rating'] ?? 5)));
    $guest_name  = $_POST['guest_name'] ?? '';
    $guest_email = $_POST['guest_email'] ?? '';

    $fb   = mysqli_real_escape_string($conn, $feedback);
    $gn   = mysqli_real_escape_string($conn, $guest_name);
    $ge   = mysqli_real_escape_string($conn, $guest_email);

    if ($loggedIn) {
        $sql = "INSERT INTO feedback (user_id, feedback_text, rating) VALUES ($user_id, '$fb', $rating)";
    } else {
        if (trim($guest_name) === '') {
            $error = 'Please enter your name.';
        } else {
            $sql = "INSERT INTO feedback (user_id, guest_name, guest_email, feedback_text, rating)
                    VALUES (NULL, '$gn', '$ge', '$fb', $rating)";
        }
    }

    if (empty($error) && isset($sql) && mysqli_query($conn, $sql)) {
        $success = 'Thank you. Your feedback has been sent to our team for review.';
        if ($loggedIn) {
            logActivity($conn, $user_id, 'Feedback submitted', substr($feedback, 0, 100));
        }
    } elseif (empty($error)) {
        $error = 'Unable to submit. Please try again.';
    }
}

$all_res = null;
if ($loggedIn) {
    $all_res = mysqli_query($conn, "SELECT rating, feedback_text, created_at FROM feedback WHERE user_id = $user_id ORDER BY id DESC");
}

if ($loggedIn) {
    page_open('Feedback');
    render_user_navbar('feedback');
} else {
    page_open('Feedback');
    render_public_navbar(false, true, 'feedback');
}
?>
<main class="page-main container page-main--narrow">
    <?php render_page_head('Feedback', 'Share your experience with Nova AI. No account needed — our team reviews every message.'); ?>
    <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

    <form method="POST" action="" class="card">
        <?php if (!$loggedIn): ?>
        <label>Your name</label>
        <input type="text" name="guest_name" required placeholder="Your name">
        <label>Email <span style="color:#64748b;font-weight:400;">(optional)</span></label>
        <input type="email" name="guest_email" placeholder="you@example.com">
        <?php endif; ?>
        <label>Rating</label>
        <select name="rating"><?php for ($i = 5; $i >= 1; $i--): ?><option value="<?= $i ?>"><?= $i ?> / 5</option><?php endfor; ?></select>
        <label>Your feedback</label>
        <textarea name="feedback_text" required rows="5" placeholder="Tell us what you think about Nova AI…"></textarea>
        <button type="submit" class="btn">Submit feedback</button>
    </form>

    <?php if ($loggedIn && $all_res && mysqli_num_rows($all_res) > 0): ?>
    <p class="section-label" style="margin-top:28px;">Your past submissions</p>
    <?php while ($row = mysqli_fetch_assoc($all_res)): ?>
    <div class="card card--tight">
        <div style="color:#fbbf24;font-size:14px;margin-bottom:8px;"><?= str_repeat('★', (int)$row['rating']) ?><?= str_repeat('☆', 5 - (int)$row['rating']) ?></div>
        <p style="line-height:1.7;color:#cbd5e1;"><?= e($row['feedback_text']) ?></p>
        <small style="color:#475569;">Submitted <?= e($row['created_at']) ?></small>
    </div>
    <?php endwhile; ?>
    <?php endif; ?>
</main>
<?php page_close(); ?>
