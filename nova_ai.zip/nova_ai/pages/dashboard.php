<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';

requireLogin();

$user_id = (int)$_SESSION['user_id'];
$recent_chats = mysqli_query($conn, "SELECT id, title, created_at FROM chat_sessions WHERE user_id=$user_id ORDER BY id DESC LIMIT 8");

page_open('Home');
render_user_navbar('dashboard');
?>
<main class="page-main container page-main--narrow">
    <div class="home-minimal">
        <a href="chat.php" class="home-new-chat">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
            New chat
        </a>

        <?php if ($recent_chats && mysqli_num_rows($recent_chats)): ?>
        <div class="home-chats">
            <?php while ($c = mysqli_fetch_assoc($recent_chats)): ?>
            <a href="chat.php" onclick="sessionStorage.setItem('loadSession','<?= (int)$c['id'] ?>');return true;" class="home-chat-row">
                <span class="home-chat-title"><?= e($c['title'] ?: 'Chat') ?></span>
                <span class="home-chat-date"><?= e(date('M j', strtotime($c['created_at']))) ?></span>
            </a>
            <?php endwhile; ?>
        </div>
        <?php endif; ?>
    </div>
</main>
<?php page_close(); ?>
