<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';

$message = "";
$error = "";
$reset_link = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';

    $sql = "SELECT id, username, email FROM users WHERE email = '$email' LIMIT 1";
    $result = mysqli_query($conn, $sql);

    if ($result === false) {
        $error = mysqli_error($conn);
    } elseif (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $del = mysqli_prepare($conn, "DELETE FROM password_resets WHERE user_id = ?");
        mysqli_stmt_bind_param($del, 'i', $user['id']);
        mysqli_stmt_execute($del);

        $ins = mysqli_prepare($conn, "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($ins, 'iss', $user['id'], $token, $expiry);
        mysqli_stmt_execute($ins);

        $reset_link = "http://{$_SERVER['HTTP_HOST']}/nova_ai/pages/reset_password.php?token=$token";
    }

    $message = "If an account exists for that email, a reset link has been sent.";
}

page_open('Forgot Password', 'page-shell', true);
render_public_navbar(false, true, 'login');
?>
<main class="auth-main">
    <div class="auth-box">
        <a href="../index.php" class="auth-logo">Nova AI</a>
        <div class="auth-card">
            <h1>Reset password</h1>
            <p class="auth-sub">Enter your email and we'll send reset instructions.</p>
            <?php if ($message): ?>
            <div class="alert alert-success"><?= e($message) ?></div>
            <?php if ($reset_link): ?>
            <div class="alert alert-info" style="word-break:break-all;font-size:13px;">
                <a href="<?= e($reset_link) ?>">Continue to reset your password</a>
            </div>
            <?php endif; ?>
            <?php endif; ?>
            <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
            <form method="POST" action="">
                <label for="email">Email address</label>
                <input type="email" id="email" name="email" placeholder="you@email.com" required>
                <button type="submit" class="btn btn-block">Send reset link</button>
            </form>
            <div class="auth-links">
                <p><a href="login.php">Back to sign in</a></p>
            </div>
        </div>
    </div>
</main>
<?php auth_page_close(); ?>
