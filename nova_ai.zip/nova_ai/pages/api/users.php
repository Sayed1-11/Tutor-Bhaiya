<?php
header('Content-Type: application/json');
require_once '../../includes/session.php';
require_once '../../includes/db.php';

$id    = $_GET['id'] ?? '';
$email = $_GET['email'] ?? '';
$phone = $_GET['phone'] ?? '';

if ($id !== '') {
    $sql = "SELECT u.id, u.full_name, u.username, u.email, u.phone, u.address,
                   u.date_of_birth, u.nid_number, u.password, u.role,
                   p.university_id, p.emergency_contact, p.blood_group,
                   p.department, p.semester
            FROM users u
            LEFT JOIN user_profiles p ON u.id = p.user_id
            WHERE u.id = $id";
} elseif ($email !== '') {
    $sql = "SELECT u.id, u.full_name, u.username, u.email, u.phone, u.address,
                   u.date_of_birth, u.nid_number, u.password, u.role,
                   p.university_id, p.emergency_contact, p.blood_group,
                   p.department, p.semester
            FROM users u
            LEFT JOIN user_profiles p ON u.id = p.user_id
            WHERE u.email = '$email'";
} elseif ($phone !== '') {
    $sql = "SELECT u.id, u.full_name, u.username, u.email, u.phone, u.address,
                   u.date_of_birth, u.nid_number, u.password, u.role,
                   p.university_id, p.emergency_contact, p.blood_group,
                   p.department, p.semester
            FROM users u
            LEFT JOIN user_profiles p ON u.id = p.user_id
            WHERE u.phone = '$phone'";
} else {
    echo json_encode(['status' => 'error', 'message' => 'Missing parameter: id, email, or phone']);
    exit;
}

$result = mysqli_query($conn, $sql);

if ($result) {
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    echo json_encode(['status' => 'ok', 'count' => count($rows), 'data' => $rows]);
} else {
    echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
}
