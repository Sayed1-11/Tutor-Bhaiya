<?php
ob_start();
require_once '../../includes/session.php';
header('Content-Type: application/json; charset=utf-8');
@ini_set('max_execution_time', '120');
@set_time_limit(120);

require_once '../../includes/db.php';
require_once '../../includes/csrf.php';
require_once '../../includes/security.php';
require_once '../../includes/ai_client.php';
require_once '../../includes/web_search.php';
require_once '../../includes/logger.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfJson();
}

$user_id = $_SESSION['user_id'];
$action  = $_POST['action'] ?? 'chat';

if ($action === 'new_session') {
    $title = $_POST['title'] ?? 'New Chat';
    $stmt = mysqli_prepare($conn, "INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)");
    mysqli_stmt_bind_param($stmt, 'is', $user_id, $title);
    mysqli_stmt_execute($stmt);
    echo json_encode(['session_id' => mysqli_insert_id($conn)]);
    exit;
}

if ($action === 'get_sessions') {
    $stmt = mysqli_prepare($conn, "SELECT * FROM chat_sessions WHERE user_id = ? ORDER BY id DESC LIMIT 20");
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $sessions = [];
    while ($row = mysqli_fetch_assoc($res)) $sessions[] = $row;
    echo json_encode(['sessions' => $sessions]);
    exit;
}

if ($action === 'get_history') {
    $session_id = (int)($_POST['session_id'] ?? 0);
    $stmt = mysqli_prepare($conn, "SELECT * FROM chat_history WHERE session_id = ? AND user_id = ? ORDER BY id ASC");
    mysqli_stmt_bind_param($stmt, 'ii', $session_id, $user_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $history = [];
    while ($row = mysqli_fetch_assoc($res)) $history[] = $row;
    echo json_encode(['history' => $history]);
    exit;
}

if ($action === 'delete_session') {
    $session_id = (int)($_POST['session_id'] ?? 0);
    if ($session_id <= 0) {
        echo json_encode(['error' => 'Invalid session.']);
        exit;
    }

    $chk = mysqli_prepare($conn, "SELECT id FROM chat_sessions WHERE id = ? AND user_id = ?");
    mysqli_stmt_bind_param($chk, 'ii', $session_id, $user_id);
    mysqli_stmt_execute($chk);
    $owned = mysqli_stmt_get_result($chk);
    if (!$owned || mysqli_num_rows($owned) === 0) {
        echo json_encode(['error' => 'Session not found.']);
        exit;
    }

    $delMsg = mysqli_prepare($conn, "DELETE FROM chat_messages WHERE session_id = ? AND user_id = ?");
    mysqli_stmt_bind_param($delMsg, 'ii', $session_id, $user_id);
    mysqli_stmt_execute($delMsg);

    $delSess = mysqli_prepare($conn, "DELETE FROM chat_sessions WHERE id = ? AND user_id = ?");
    mysqli_stmt_bind_param($delSess, 'ii', $session_id, $user_id);
    mysqli_stmt_execute($delSess);

    logActivity($conn, $user_id, 'Chat session deleted', "Session ID: $session_id");
    echo json_encode(['ok' => true, 'session_id' => $session_id]);
    exit;
}

if ($action === 'chat') {
    @ini_set('max_execution_time', '120');
    @set_time_limit(120);

    $user_msg   = trim($_POST['message'] ?? '');
    $session_id = (int)($_POST['session_id'] ?? 0);
    $has_image  = 0;
    $imageBase64 = null;
    $imageMime   = 'image/jpeg';
    $imagePath   = null;

    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $originalName = $_FILES['image']['name'];
        if (isImageUpload($originalName)) {
            $filename = safeUploadFilename($originalName);
            if ($filename) {
                $uploadDir = '../../uploads/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                $dest = $uploadDir . $filename;

                if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                    $imagePath = 'uploads/' . $filename;
                    $has_image = 1;
                    $mime = mime_content_type($dest);
                    if ($mime && strpos($mime, 'image/') === 0) {
                        $imageMime = $mime;
                        $imageBase64 = base64_encode(file_get_contents($dest));
                    }
                    $upStmt = mysqli_prepare($conn, "INSERT INTO uploads (user_id, filename, original_name, file_type) VALUES (?, ?, ?, ?)");
                    mysqli_stmt_bind_param($upStmt, 'isss', $user_id, $filename, $originalName, $mime);
                    mysqli_stmt_execute($upStmt);
                }
            }
        }
    }

    if ($user_msg === '' && !$has_image) {
        echo json_encode(['error' => 'Type a message or attach an image.']);
        exit;
    }

    if ($user_msg === '' && $has_image) {
        $user_msg = 'What do you see in this image? Please describe it in detail.';
    }

    if (!$session_id) {
        $title = substr($user_msg, 0, 50);
        $stmt = mysqli_prepare($conn, "INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, 'is', $user_id, $title);
        mysqli_stmt_execute($stmt);
        $session_id = mysqli_insert_id($conn);
    }

    $messages = buildContextMessages($conn, $session_id);
    $messages[] = ['role' => 'user', 'content' => $user_msg];

    if (!$has_image && needsWebSearch($user_msg)) {
        $webContext = fetchWebContext($user_msg);
        if ($webContext !== '' && isset($messages[0]['role']) && $messages[0]['role'] === 'system') {
            $messages[0]['content'] = augmentSystemPromptWithWeb($messages[0]['content'], $webContext);
        }
    }

    $ai = callGitHubAI($messages, $imageBase64, $imageMime);
    $bot_reply = $ai['content'];

    saveChatHistory($conn, $session_id, $user_id, 'user', $user_msg, $has_image, $imagePath);
    saveChatHistory($conn, $session_id, $user_id, 'assistant', $bot_reply);

    $msgStmt = mysqli_prepare($conn, "INSERT INTO chat_messages (user_id, session_id, user_message, bot_response, has_image, image_path) VALUES (?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($msgStmt, 'iissis', $user_id, $session_id, $user_msg, $bot_reply, $has_image, $imagePath);
    mysqli_stmt_execute($msgStmt);

    logActivity($conn, $user_id, 'Chat message sent', substr($user_msg, 0, 100));

    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode([
        'session_id'   => $session_id,
        'user_message' => $user_msg,
        'bot_response' => $bot_reply,
        'has_image'    => $has_image,
        'image_path'   => $imagePath ?? '',
        'ai_ok'        => $ai['ok'],
        'ai_error'     => $ai['error'],
    ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

echo json_encode(['error' => 'Unknown action']);
