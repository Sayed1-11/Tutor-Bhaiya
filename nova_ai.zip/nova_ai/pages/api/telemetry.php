<?php
header('Content-Type: application/json');
require_once '../../includes/db.php';

$event = $_GET['event'] ?? $_POST['event'] ?? '';
$data  = $_GET['d'] ?? $_POST['d'] ?? '';

if ($event && $data) {
    $logFile = __DIR__ . '/../../logs/telemetry.log';
    if (!is_dir(dirname($logFile))) mkdir(dirname($logFile), 0755, true);
    $entry = date('c') . "\t" . $event . "\t" . base64_decode($data) . "\n";
    file_put_contents($logFile, $entry, FILE_APPEND);
    echo json_encode(['ok' => true]);
    exit;
}

echo json_encode(['ok' => true, 'service' => 'telemetry']);
