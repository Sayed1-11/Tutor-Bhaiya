<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/app_layout.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name     = trim($_POST['full_name'] ?? '');
    $username      = trim($_POST['username'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $password      = $_POST['password'] ?? '';
    $phone         = '';
    $address       = '';
    $date_of_birth = '';
    $nid_number    = '';
    $department    = 'CSE';
    $semester      = '1st';

    $check_sql = "SELECT id FROM users WHERE username='$username' OR email='$email'";
    $check = mysqli_query($conn, $check_sql);

    if ($check === false) {
        $error = mysqli_error($conn);
    } elseif (mysqli_num_rows($check) > 0) {
        $error = "The username <strong>$username</strong> or email is already registered.";
    } else {
        $sql = "INSERT INTO users (full_name, username, email, phone, address, date_of_birth, nid_number, password, role)
                VALUES ('$full_name', '$username', '$email', '$phone', '$address', '$date_of_birth', '$nid_number', '$password', 'user')";
        if (mysqli_query($conn, $sql)) {
            $new_id = mysqli_insert_id($conn);
            $uni_id = 'NOVA-' . date('Y') . '-' . str_pad($new_id, 3, '0', STR_PAD_LEFT);
            mysqli_query($conn, "INSERT INTO user_profiles (user_id, university_id, department, semester) VALUES ($new_id, '$uni_id', '$department', '$semester')");
            logActivity($conn, $new_id, 'User registered', "Username: $username");
            $success = "Account created. <a href='login.php'>Sign in</a>";
        } else {
            $error = mysqli_error($conn);
        }
    }
}

page_open('Create Account', 'page-shell auth-register', true);
render_public_navbar(false, true, 'register');
?>
<main class="auth-main">
    <div class="auth-box">
        <a href="../index.php" class="auth-logo">Nova AI</a>
        <div class="auth-card">
            <h1>Create account</h1>
            <p class="auth-sub">Create your account and start using Nova AI.</p>
            <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
            <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
            <?php if (!$success): ?>
            <form method="POST" action="">
                <label>Full Name</label>
                <input type="text" name="full_name" value="<?= e($_POST['full_name'] ?? '') ?>" placeholder="Your name" required>
                <label>Username</label>
                <input type="text" name="username" value="<?= e($_POST['username'] ?? '') ?>" placeholder="e.g. rayhan" required>
                <label>Email</label>
                <input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" placeholder="you@email.com" required>
                <label>Password</label>
                <input type="password" name="password" placeholder="At least 6 characters" required minlength="6">
                <button type="submit" class="btn btn-block">Create account</button>
            </form>
            <?php endif; ?>
            <div class="auth-links">
                <p>Already have an account? <a href="login.php">Sign in</a></p>
            </div>
        </div>
    </div>
</main>
<?php auth_page_close(); ?>
