<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';

requireLogin();
$user_id = $_SESSION['user_id'];
$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
    $originalName = $_FILES['document']['name'];
    $filename = time() . '_' . basename($originalName);
    $uploadDir = '../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    $dest = $uploadDir . $filename;

    if (move_uploaded_file($_FILES['document']['tmp_name'], $dest)) {
        $mime = mime_content_type($dest) ?: 'application/octet-stream';
        $stmt = mysqli_prepare($conn, "INSERT INTO uploads (user_id, filename, original_name, file_type) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'isss', $user_id, $filename, $originalName, $mime);
        mysqli_stmt_execute($stmt);
        $success = "File uploaded successfully.";
    } else {
        $error = "Upload failed. Please try again.";
    }
}

$files = mysqli_query($conn, "SELECT * FROM uploads WHERE user_id=$user_id ORDER BY id DESC");

page_open('My Files');
render_user_navbar('files');
?>
<main class="page-main container page-main--narrow">
    <?php render_page_head('My files', 'Upload and manage your documents.'); ?>
    <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" enctype="multipart/form-data" class="card">
        <label>Upload document</label>
        <input type="file" name="document" required>
        <button type="submit" class="btn">Upload</button>
    </form>
    <div class="card" style="padding:0;overflow:hidden;margin-top:24px;">
        <table>
            <thead><tr><th>File</th><th>Type</th><th>Uploaded</th><th></th></tr></thead>
            <tbody>
                <?php if ($files): while ($f = mysqli_fetch_assoc($files)): ?>
                <tr>
                    <td><?= e($f['original_name']) ?></td>
                    <td><?= e($f['file_type']) ?></td>
                    <td><?= e($f['uploaded_at']) ?></td>
                    <td><a href="../uploads/<?= e($f['filename']) ?>" target="_blank">Open</a></td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="4" style="color:#64748b;padding:16px;">No files uploaded yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
<?php page_close(); ?>
