<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/app_layout.php';

$loggedIn = isset($_SESSION['user_id']);
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $message = $_POST['message'] ?? '';

    $sql = "INSERT INTO contact_messages (name, email, phone, message) VALUES ('$name', '$email', '$phone', '$message')";
    if (mysqli_query($conn, $sql)) {
        $success = "Thank you, <strong>$name</strong>. We received your message and will reply to <em>$email</em> shortly.";
    } else {
        $success = mysqli_error($conn);
    }
}

page_open('Contact');
render_public_navbar($loggedIn, true);
?>
<main class="page-main container page-main--narrow">
    <?php render_page_head('Contact', 'Reach student affairs, IT helpdesk, or department coordinators.'); ?>
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <form method="POST" class="card">
        <label>Name</label><input type="text" name="name" required>
        <label>Email</label><input type="email" name="email" required>
        <label>Phone</label><input type="text" name="phone">
        <label>Message</label><textarea name="message" required></textarea>
        <button type="submit" class="btn">Send</button>
    </form>
</main>
<?php page_close(); ?>
