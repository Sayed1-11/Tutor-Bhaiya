<?php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/app_layout.php';

requireLogin();
$user_id = $_SESSION['user_id'];
$success = "";
$error = "";

$sql = "SELECT u.*, p.bio, p.emergency_contact, p.blood_group, p.department, p.semester
        FROM users u LEFT JOIN user_profiles p ON u.id=p.user_id WHERE u.id = $user_id";
$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
$user = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'] ?? '';
    $email     = $_POST['email'] ?? '';
    $phone     = $_POST['phone'] ?? '';
    $address   = $_POST['address'] ?? '';
    $date_of_birth = $_POST['date_of_birth'] ?? '';
    $nid_number = $_POST['nid_number'] ?? '';
    $bio       = $_POST['bio'] ?? '';
    $emergency = $_POST['emergency_contact'] ?? '';
    $blood_group = $_POST['blood_group'] ?? '';
    $department = $_POST['department'] ?? '';
    $semester  = $_POST['semester'] ?? '';

    $upd = "UPDATE users SET full_name='$full_name', email='$email', phone='$phone', address='$address',
            date_of_birth='$date_of_birth', nid_number='$nid_number' WHERE id=$user_id";
    if (mysqli_query($conn, $upd)) {
        $prof = "UPDATE user_profiles SET bio='$bio', emergency_contact='$emergency', blood_group='$blood_group',
                 department='$department', semester='$semester' WHERE user_id=$user_id";
        mysqli_query($conn, $prof);
        logActivity($conn, $user_id, 'Profile updated', "Email: $email");
        $success = "Profile saved.";
        $result = mysqli_query($conn, $sql);
        $user = mysqli_fetch_assoc($result);
    } else {
        $error = mysqli_error($conn);
    }
}

page_open('Edit Profile');
render_user_navbar('profile');
?>
<main class="page-main container page-main--narrow">
    <?php render_page_head('Edit profile', 'Update your contact and academic information.'); ?>
    <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
    <form method="POST" class="card">
        <label>Full Name</label><input type="text" name="full_name" value="<?= e($user['full_name']) ?>">
        <label>Email</label><input type="email" name="email" value="<?= e($user['email']) ?>">
        <label>Phone</label><input type="text" name="phone" value="<?= e($user['phone']) ?>">
        <label>Address</label><input type="text" name="address" value="<?= e($user['address']) ?>">
        <label>Date of Birth</label><input type="date" name="date_of_birth" value="<?= e($user['date_of_birth']) ?>">
        <label>NID</label><input type="text" name="nid_number" value="<?= e($user['nid_number']) ?>">
        <label>Bio</label><textarea name="bio"><?= e($user['bio']) ?></textarea>
        <label>Emergency Contact</label><input type="text" name="emergency_contact" value="<?= e($user['emergency_contact']) ?>">
        <label>Blood Group</label><input type="text" name="blood_group" value="<?= e($user['blood_group'] ?? '') ?>">
        <label>Department</label><input type="text" name="department" value="<?= e($user['department']) ?>">
        <label>Semester</label><input type="text" name="semester" value="<?= e($user['semester']) ?>">
        <button type="submit" class="btn">Save</button>
    </form>
</main>
<?php page_close(); ?>
