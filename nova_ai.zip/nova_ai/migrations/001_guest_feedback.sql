-- Run once on existing nova_ai database
USE nova_ai;

ALTER TABLE feedback MODIFY user_id INT NULL;
ALTER TABLE feedback ADD COLUMN guest_name VARCHAR(255) NULL AFTER user_id;
ALTER TABLE feedback ADD COLUMN guest_email VARCHAR(255) NULL AFTER guest_name;
