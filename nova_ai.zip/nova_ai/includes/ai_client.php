<?php

function nova_system_prompt(): string {
    return 'You are Nova AI, an intelligent assistant similar to ChatGPT. '
        . 'Give helpful, accurate, and natural responses. '
        . 'You can answer questions, explain concepts, write code, brainstorm ideas, and analyze images when the user uploads them. '
        . 'When web search context is provided, use it for current sports fixtures, news, weather, and other time-sensitive facts. '
        . 'Reply in the same language the user uses (English or Bengali). '
        . 'Use markdown when it improves clarity: headings, bullet lists, bold, and fenced code blocks for code. '
        . 'Be concise but thorough. If you are unsure, say so honestly.';
}

function callGitHubAI(array $messages, ?string $imageBase64 = null, string $imageMime = 'image/jpeg'): array {
    $token = getenv('GITHUB_TOKEN');
    $token = $token ? trim($token, " \t\n\r\0\x0B\"'") : '';

    if (!$token || $token === 'your_github_token_here') {
        return [
            'ok' => false,
            'content' => getFallbackResponse($messages),
            'error' => 'GITHUB_TOKEN not configured. Add your token to config/.env',
        ];
    }

    $model = $imageBase64
        ? (getenv('AI_VISION_MODEL') ?: 'openai/gpt-4o')
        : (getenv('AI_MODEL') ?: 'openai/gpt-4o-mini');

    if ($imageBase64) {
        $lastIdx = count($messages) - 1;
        $textContent = $messages[$lastIdx]['content'];
        if (is_array($textContent)) {
            $textContent = $textContent[0]['text'] ?? 'Describe this image.';
        }
        $messages[$lastIdx]['content'] = [
            ['type' => 'text', 'text' => $textContent ?: 'What is in this image?'],
            ['type' => 'image_url', 'image_url' => [
                'url' => "data:{$imageMime};base64,{$imageBase64}",
            ]],
        ];
    }

    $maxTokens = (int)(getenv('AI_MAX_TOKENS') ?: 2048);

    $payload = json_encode([
        'model' => $model,
        'messages' => $messages,
        'max_tokens' => max(256, min(4096, $maxTokens)),
        'temperature' => 0.7,
    ]);

    $ch = curl_init('https://models.github.ai/inference/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 90,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/vnd.github+json',
        ],
        CURLOPT_POSTFIELDS => $payload,
    ]);

    $response = curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($httpCode !== 200 || !$response) {
        $detail = $curlErr ?: "HTTP $httpCode";
        if ($response) {
            $err = json_decode($response, true);
            if (!empty($err['error']['message'])) {
                $detail = $err['error']['message'];
            }
        }
        return [
            'ok' => false,
            'content' => getFallbackResponse($messages),
            'error' => $detail,
        ];
    }

    $data = json_decode($response, true);
    $content = $data['choices'][0]['message']['content'] ?? null;

    if (!$content) {
        return [
            'ok' => false,
            'content' => getFallbackResponse($messages),
            'error' => 'Empty response from model',
        ];
    }

    return ['ok' => true, 'content' => $content, 'error' => null];
}

function getFallbackResponse(array $messages): string {
    $last = end($messages);
    $msg = '';
    if (is_array($last['content'] ?? null)) {
        foreach ($last['content'] as $part) {
            if (($part['type'] ?? '') === 'text') {
                $msg = strtolower($part['text'] ?? '');
                break;
            }
        }
    } else {
        $msg = strtolower((string)($last['content'] ?? ''));
    }

    if (strpos($msg, 'hello') !== false || strpos($msg, 'hi') !== false || strpos($msg, 'হ্যালো') !== false || strpos($msg, 'হাই') !== false) {
        return "Hello! I'm Nova AI. Ask me anything — I can help with questions, coding, writing, and image analysis.";
    }
    if (strpos($msg, 'help') !== false || strpos($msg, 'সাহায্য') !== false) {
        return "I can answer questions, analyze uploaded images, and chat by voice. Type a message, attach an image, or use the mic button.";
    }

    return "I'm Nova AI. Configure your GitHub Models token in config/.env (GITHUB_TOKEN) for full ChatGPT-style replies. Until then, I can only give basic responses.";
}

function buildContextMessages($conn, $session_id, ?string $systemPrompt = null): array {
    $messages = [];
    $messages[] = ['role' => 'system', 'content' => $systemPrompt ?: nova_system_prompt()];

    if (!$session_id) {
        return $messages;
    }

    $stmt = mysqli_prepare($conn, "SELECT role, content FROM chat_history WHERE session_id = ? ORDER BY id ASC LIMIT 30");
    mysqli_stmt_bind_param($stmt, 'i', $session_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $messages[] = ['role' => $row['role'], 'content' => $row['content']];
        }
    }

    return $messages;
}

function saveChatHistory($conn, $session_id, $user_id, $role, $content, $has_image = 0, $image_path = null): void {
    $stmt = mysqli_prepare($conn, "INSERT INTO chat_history (session_id, user_id, role, content, has_image, image_path) VALUES (?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, 'iissis', $session_id, $user_id, $role, $content, $has_image, $image_path);
    mysqli_stmt_execute($stmt);
}

/** Backward-compatible wrapper */
function callGitHubAI_text(array $messages, ?string $imageBase64 = null, string $imageMime = 'image/jpeg'): string {
    $result = callGitHubAI($messages, $imageBase64, $imageMime);
    return $result['content'];
}
