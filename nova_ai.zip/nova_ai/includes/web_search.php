<?php

/**
 * Live context for current-events questions (sports schedules, news, etc.).
 */

function needsWebSearch(string $message): bool {
    $msg = mb_strtolower(trim($message), 'UTF-8');
    if ($msg === '') {
        return false;
    }

    $patterns = [
        'next match', 'next game', 'fixture', 'schedule', 'kick off', 'kickoff',
        'world cup', 'fifa', 'premier league', 'champions league', 'la liga',
        'bundesliga', 'serie a', 'mls', 'score', 'result', 'standings', 'lineup',
        'playing today', 'match today', 'who is playing', 'who won',
        'today', 'tonight', 'tomorrow', 'this week', 'right now', 'currently',
        'latest', 'recent', 'news', 'live', 'update', 'happening now',
        'weather', 'forecast',
        'পরবর্তী', 'আজক', 'আজ', 'সর্বশেষ', 'খবর', 'ম্যাচ', 'ফাইনাল',
        'বিশ্বকাপ', 'ফিফা', 'ফিক্সচার', 'সূচি',
    ];

    foreach ($patterns as $needle) {
        if (mb_strpos($msg, $needle, 0, 'UTF-8') !== false) {
            return true;
        }
    }

    return (bool) preg_match(
        '/\b(20\d{2})\b.*\b(match|cup|final|semifinal|quarter|group stage)\b/i',
        $message
    );
}

function buildSearchQuery(string $message): string {
    $q = trim($message);
    if (!preg_match('/\b20\d{2}\b/', $q)) {
        $q .= ' ' . date('Y');
    }
    return $q;
}

function fetchWebContext(string $message): string {
    $parts = [];

    $sports = fetchSportsContext($message);
    if ($sports !== '') {
        $parts[] = $sports;
    }

    $wiki = fetchWikipediaContext($message);
    if ($wiki !== '') {
        $parts[] = $wiki;
    }

    if (empty($parts)) {
        $ddg = fetchDuckDuckGoContext(buildSearchQuery($message));
        if ($ddg !== '') {
            $parts[] = $ddg;
        }
    }

    return implode("\n\n", $parts);
}

function fetchSportsContext(string $message): string {
    $msg = mb_strtolower($message, 'UTF-8');
    $league = null;

    if (mb_strpos($msg, 'fifa', 0, 'UTF-8') !== false
        || mb_strpos($msg, 'world cup', 0, 'UTF-8') !== false
        || mb_strpos($msg, 'বিশ্বকাপ', 0, 'UTF-8') !== false
        || mb_strpos($msg, 'ফিফা', 0, 'UTF-8') !== false) {
        $league = 'fifa.world';
    } elseif (mb_strpos($msg, 'champions league', 0, 'UTF-8') !== false) {
        $league = 'uefa.champions';
    } elseif (mb_strpos($msg, 'premier league', 0, 'UTF-8') !== false) {
        $league = 'eng.1';
    } elseif (mb_strpos($msg, 'la liga', 0, 'UTF-8') !== false) {
        $league = 'esp.1';
    }

    if ($league === null && preg_match('/\b(match|matches|fixture|schedule|score|game|ম্যাচ)\b/ui', $message)) {
        $league = 'fifa.world';
    }

    if ($league === null) {
        return '';
    }

    return formatEspnScoreboard($league);
}

function formatEspnScoreboard(string $leagueSlug): string {
    $url = 'https://site.api.espn.com/apis/site/v2/sports/soccer/' . rawurlencode($leagueSlug) . '/scoreboard';
    $json = webSearchHttpGet($url, 20);
    if ($json === '') {
        return '';
    }

    $data = json_decode($json, true);
    if (!is_array($data) || empty($data['events'])) {
        return '';
    }

    $leagueName = $data['leagues'][0]['name'] ?? 'Soccer';
    $lines = ["ESPN live schedule — {$leagueName} (fetched " . date('Y-m-d H:i') . ' UTC):'];

    foreach ($data['events'] as $event) {
        $comp = $event['competitions'][0] ?? null;
        if (!$comp) {
            continue;
        }

        $name = $event['name'] ?? $event['shortName'] ?? 'Match';
        $status = $comp['status']['type']['description'] ?? 'Scheduled';
        $detail = $comp['status']['type']['detail'] ?? '';
        $venue = $comp['venue']['fullName'] ?? '';
        $city = $comp['venue']['address']['city'] ?? '';

        $teams = [];
        foreach ($comp['competitors'] ?? [] as $team) {
            $teams[] = ($team['team']['displayName'] ?? 'Team') . ' (' . ($team['score'] ?? '-') . ')';
        }
        $teamLine = $teams ? implode(' vs ', $teams) : $name;

        $lines[] = "- {$teamLine}";
        $lines[] = "  Status: {$status}" . ($detail ? " — {$detail}" : '');
        if ($venue) {
            $lines[] = '  Venue: ' . $venue . ($city ? ", {$city}" : '');
        }
    }

    return implode("\n", $lines);
}

function fetchWikipediaContext(string $message): string {
    $query = buildSearchQuery($message);
    $searchUrl = 'https://en.wikipedia.org/w/api.php?' . http_build_query([
        'action' => 'query',
        'list' => 'search',
        'srsearch' => $query,
        'srlimit' => 1,
        'format' => 'json',
    ]);

    $searchJson = webSearchHttpGet($searchUrl, 12);
    if ($searchJson === '') {
        return '';
    }

    $searchData = json_decode($searchJson, true);
    $title = $searchData['query']['search'][0]['title'] ?? null;
    if (!$title) {
        return '';
    }

    $extractUrl = 'https://en.wikipedia.org/w/api.php?' . http_build_query([
        'action' => 'query',
        'prop' => 'extracts',
        'exintro' => true,
        'explaintext' => true,
        'titles' => $title,
        'format' => 'json',
    ]);

    $extractJson = webSearchHttpGet($extractUrl, 12);
    if ($extractJson === '') {
        return '';
    }

    $extractData = json_decode($extractJson, true);
    $pages = $extractData['query']['pages'] ?? [];
    $page = reset($pages);
    $extract = trim($page['extract'] ?? '');
    if ($extract === '') {
        return '';
    }

    if (mb_strlen($extract) > 1200) {
        $extract = mb_substr($extract, 0, 1200) . '…';
    }

    return "Wikipedia ({$title}):\n{$extract}";
}

function fetchDuckDuckGoContext(string $query): string {
    $parts = [];
    $instant = ddgInstantAnswer($query);
    if ($instant !== '') {
        $parts[] = "DuckDuckGo summary:\n" . $instant;
    }
    return implode("\n\n", $parts);
}

function ddgInstantAnswer(string $query): string {
    $url = 'https://api.duckduckgo.com/?' . http_build_query([
        'q' => $query,
        'format' => 'json',
        'no_redirect' => 1,
        'skip_disambig' => 1,
    ]);

    $json = webSearchHttpGet($url, 12);
    if ($json === '') {
        return '';
    }

    $data = json_decode($json, true);
    if (!is_array($data)) {
        return '';
    }

    $chunks = [];
    if (!empty($data['AbstractText'])) {
        $chunks[] = $data['AbstractText'];
    }
    if (!empty($data['Answer'])) {
        $chunks[] = 'Answer: ' . $data['Answer'];
    }

    return implode("\n", $chunks);
}

function webSearchHttpGet(string $url, int $timeout = 15): string {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; NovaAI/1.0)',
    ]);
    $body = curl_exec($ch);
    curl_close($ch);
    return is_string($body) ? $body : '';
}

function augmentSystemPromptWithWeb(string $basePrompt, string $webContext): string {
    if (trim($webContext) === '') {
        return $basePrompt;
    }

    return $basePrompt
        . "\n\nToday's date: " . date('l, F j, Y') . "."
        . "\nUse the live context below for current schedules, scores, and recent events. Prefer these facts over outdated training data.\n\n"
        . "=== LIVE WEB CONTEXT ===\n"
        . $webContext
        . "\n=== END LIVE CONTEXT ===";
}
