<?php

function logActivity($conn, $user_id, $action, $details = '') {
    $ip = getClientIP();
    $stmt = mysqli_prepare($conn, "INSERT INTO activity_log (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, 'isss', $user_id, $action, $details, $ip);
    mysqli_stmt_execute($stmt);

    $logStmt = mysqli_prepare($conn, "INSERT INTO chatbot_logs (user_id, activity, ip_address) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($logStmt, 'iss', $user_id, $action, $ip);
    mysqli_stmt_execute($logStmt);
}
