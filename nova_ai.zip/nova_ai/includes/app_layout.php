<?php

/**
 * Shared layout: navbar, footer, and page structure.
 */

function nav_active(string $page, string $current): string {
    return $page === $current ? ' active' : '';
}

function nav_link_class(string $page, string $current): string {
    return 'nav-link' . nav_active($page, $current);
}

function render_nav_shell_start(string $logoHref, string $logoText): void {
    ?>
<header class="site-nav page-header">
    <div class="site-nav-inner">
        <a href="<?= htmlspecialchars($logoHref, ENT_QUOTES, 'UTF-8') ?>" class="logo"><?= htmlspecialchars($logoText, ENT_QUOTES, 'UTF-8') ?></a>
        <button type="button" class="nav-toggle" aria-label="Open menu" aria-expanded="false">
            <span></span><span></span><span></span>
        </button>
        <nav class="nav-desktop nav-links" aria-label="Main navigation">
    <?php
}

function render_nav_shell_end(): void {
    ?>
        </nav>
    </div>
    <div class="nav-overlay" aria-hidden="true"></div>
    <nav class="nav-drawer" aria-label="Mobile navigation"></nav>
</header>
    <?php
}

function render_nav_drawer_links(array $links, string $logoutHref = ''): void {
    // Drawer is populated via JS clone from desktop nav on small screens,
    // but we also output explicit mobile list for reliability.
    echo '<div class="nav-drawer-inner">';
    foreach ($links as $link) {
        $class = 'nav-drawer-link' . ($link['active'] ?? false ? ' active' : '');
        $extra = $link['class'] ?? '';
        echo '<a href="' . htmlspecialchars($link['href'], ENT_QUOTES, 'UTF-8') . '" class="' . $class . ' ' . $extra . '">' . htmlspecialchars($link['label'], ENT_QUOTES, 'UTF-8') . '</a>';
    }
    if ($logoutHref) {
        echo '<a href="' . htmlspecialchars($logoutHref, ENT_QUOTES, 'UTF-8') . '" class="nav-drawer-link nav-drawer-logout">Logout</a>';
    }
    echo '</div>';
}

function render_user_navbar(string $current = ''): void {
    $uid = (int)($_SESSION['user_id'] ?? 0);
    $isAdmin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';

    $moreActive = in_array($current, ['files', 'directory', 'feedback', 'profile', 'search_chat', 'admin'], true);

    render_nav_shell_start('chat.php', 'Nova AI');
    ?>
        <a href="chat.php" class="<?= nav_link_class('chat', $current) ?>">Chat</a>
        <a href="dashboard.php" class="<?= nav_link_class('dashboard', $current) ?>">Home</a>
        <div class="nav-dropdown<?= $moreActive ? ' active-parent' : '' ?>">
            <button type="button" class="nav-dropdown-btn" aria-haspopup="true">More ▾</button>
            <div class="nav-dropdown-menu">
                <a href="search_chat.php" class="<?= nav_link_class('search_chat', $current) ?>">Search chats</a>
                <a href="documents.php" class="<?= nav_link_class('files', $current) ?>">Files</a>
                <a href="search_users.php" class="<?= nav_link_class('directory', $current) ?>">Directory</a>
                <a href="feedback.php" class="<?= nav_link_class('feedback', $current) ?>">Feedback</a>
                <a href="profile.php?id=<?= $uid ?>" class="<?= nav_link_class('profile', $current) ?>">Profile</a>
                <?php if ($isAdmin): ?>
                <a href="admin/dashboard.php" class="<?= nav_link_class('admin', $current) ?>">Admin</a>
                <?php endif; ?>
            </div>
        </div>
        <a href="logout.php" class="btn btn-sm btn-danger nav-logout">Logout</a>
    <?php
    render_nav_shell_end();
    render_nav_script('../');

    $drawerLinks = [
        ['href' => 'chat.php', 'label' => 'Chat', 'active' => $current === 'chat'],
        ['href' => 'dashboard.php', 'label' => 'Home', 'active' => $current === 'dashboard'],
        ['href' => 'search_chat.php', 'label' => 'Search chats', 'active' => $current === 'search_chat'],
        ['href' => 'documents.php', 'label' => 'Files', 'active' => $current === 'files'],
        ['href' => 'search_users.php', 'label' => 'Directory', 'active' => $current === 'directory'],
        ['href' => 'feedback.php', 'label' => 'Feedback', 'active' => $current === 'feedback'],
        ['href' => "profile.php?id=$uid", 'label' => 'Profile', 'active' => $current === 'profile'],
    ];
    if ($isAdmin) {
        $drawerLinks[] = ['href' => 'admin/dashboard.php', 'label' => 'Admin', 'active' => $current === 'admin'];
    }
    ?>
<script>
document.currentScript.closest('.site-nav').querySelector('.nav-drawer').innerHTML = <?=
    json_encode('<div class="nav-drawer-inner">' .
        implode('', array_map(fn($l) =>
            '<a href="' . htmlspecialchars($l['href']) . '" class="nav-drawer-link' . ($l['active'] ? ' active' : '') . '">' . htmlspecialchars($l['label']) . '</a>',
            $drawerLinks)) .
        '<a href="logout.php" class="nav-drawer-link nav-drawer-logout">Logout</a></div>')
?>;
</script>
    <?php
}

function render_admin_navbar(string $current = ''): void {
    render_nav_shell_start('dashboard.php', 'Nova AI Admin');
    ?>
        <a href="dashboard.php" class="<?= nav_link_class('dashboard', $current) ?>">Dashboard</a>
        <a href="feedback.php" class="<?= nav_link_class('feedback', $current) ?>">Feedback</a>
        <a href="contacts.php" class="<?= nav_link_class('contacts', $current) ?>">Contacts</a>
        <a href="users.php" class="<?= nav_link_class('users', $current) ?>">Users</a>
        <a href="logs.php" class="<?= nav_link_class('logs', $current) ?>">Logs</a>
        <a href="settings.php" class="<?= nav_link_class('settings', $current) ?>">Settings</a>
        <a href="../dashboard.php" class="nav-link">App</a>
        <a href="../logout.php" class="btn btn-sm btn-danger nav-logout">Logout</a>
    <?php
    render_nav_shell_end();

    $links = [
        ['href' => 'dashboard.php', 'label' => 'Dashboard', 'active' => $current === 'dashboard'],
        ['href' => 'feedback.php', 'label' => 'Feedback', 'active' => $current === 'feedback'],
        ['href' => 'contacts.php', 'label' => 'Contacts', 'active' => $current === 'contacts'],
        ['href' => 'users.php', 'label' => 'Users', 'active' => $current === 'users'],
        ['href' => 'logs.php', 'label' => 'Logs', 'active' => $current === 'logs'],
        ['href' => 'settings.php', 'label' => 'Settings', 'active' => $current === 'settings'],
        ['href' => '../dashboard.php', 'label' => 'Back to app', 'active' => false],
    ];
    ?>
<script>
document.currentScript.closest('.site-nav').querySelector('.nav-drawer').innerHTML = <?=
    json_encode('<div class="nav-drawer-inner">' .
        implode('', array_map(fn($l) =>
            '<a href="' . htmlspecialchars($l['href']) . '" class="nav-drawer-link' . ($l['active'] ? ' active' : '') . '">' . htmlspecialchars($l['label']) . '</a>',
            $links)) .
        '<a href="../logout.php" class="nav-drawer-link nav-drawer-logout">Logout</a></div>')
?>;
</script>
    <?php
}

function render_public_navbar(bool $loggedIn = false, bool $inPagesDir = false, string $active = ''): void {
    $home     = $inPagesDir ? '../index.php' : 'index.php';
    $about    = $inPagesDir ? 'about.php' : 'pages/about.php';
    $login    = $inPagesDir ? 'login.php' : 'pages/login.php';
    $register = $inPagesDir ? 'register.php' : 'pages/register.php';
    $contact  = $inPagesDir ? 'contact.php' : 'pages/contact.php';
    $feedback = $inPagesDir ? 'feedback.php' : 'pages/feedback.php';
    $dash     = $inPagesDir ? 'dashboard.php' : 'pages/dashboard.php';
    $chat     = $inPagesDir ? 'chat.php' : 'pages/chat.php';
    $logout   = $inPagesDir ? 'logout.php' : 'pages/logout.php';

    render_nav_shell_start($loggedIn ? $dash : $home, 'Nova AI');
    ?>
        <a href="<?= $about ?>" class="nav-link<?= $active === 'about' ? ' active' : '' ?>">About</a>
        <a href="<?= $feedback ?>" class="nav-link<?= $active === 'feedback' ? ' active' : '' ?>">Feedback</a>
        <a href="<?= $contact ?>" class="nav-link<?= $active === 'contact' ? ' active' : '' ?>">Contact</a>
        <div class="nav-actions">
        <?php if ($loggedIn): ?>
        <a href="<?= $dash ?>" class="nav-link">Dashboard</a>
        <a href="<?= $chat ?>" class="nav-link">Chat</a>
        <a href="<?= $logout ?>" class="btn btn-sm btn-danger nav-logout">Logout</a>
        <?php else: ?>
        <?php if ($active !== 'login'): ?><a href="<?= $login ?>" class="btn btn-sm">Sign in</a><?php endif; ?>
        <?php if ($active !== 'register'): ?><a href="<?= $register ?>" class="btn btn-sm btn-outline">Register</a><?php endif; ?>
        <?php endif; ?>
        </div>
    <?php
    render_nav_shell_end();

    $links = [
        ['href' => $about, 'label' => 'About', 'active' => $active === 'about'],
        ['href' => $feedback, 'label' => 'Feedback', 'active' => $active === 'feedback'],
        ['href' => $contact, 'label' => 'Contact', 'active' => $active === 'contact'],
    ];
    if ($loggedIn) {
        $links[] = ['href' => $dash, 'label' => 'Dashboard', 'active' => false];
        $links[] = ['href' => $chat, 'label' => 'Chat', 'active' => false];
        $logoutLink = $logout;
    } else {
        $links[] = ['href' => $login, 'label' => 'Sign in', 'active' => false];
        $links[] = ['href' => $register, 'label' => 'Register', 'active' => false];
        $logoutLink = '';
    }
    ?>
<script>
document.currentScript.closest('.site-nav').querySelector('.nav-drawer').innerHTML = <?=
    json_encode('<div class="nav-drawer-inner">' .
        implode('', array_map(fn($l) =>
            '<a href="' . htmlspecialchars($l['href']) . '" class="nav-drawer-link">' . htmlspecialchars($l['label']) . '</a>',
            $links)) .
        ($logoutLink ? '<a href="' . htmlspecialchars($logoutLink) . '" class="nav-drawer-link nav-drawer-logout">Logout</a>' : '') .
        '</div>')
?>;
</script>
    <?php
}

function render_page_head(string $title, string $subtitle = ''): void {
    ?>
    <div class="page-head">
        <h1 class="page-title"><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h1>
        <?php if ($subtitle): ?>
        <p class="page-subtitle"><?= htmlspecialchars($subtitle, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>
    </div>
    <?php
}

function render_site_footer(string $prefix = '', bool $loggedIn = false): void {
    ?>
<footer class="site-footer-wrap">
    <div class="footer-grid">
        <div>
            <h4 class="footer-brand">Nova AI</h4>
            <p>Nova AI — intelligent chat assistant powered by GitHub Models. Ask anything, upload images, use voice.</p>
        </div>
        <div>
            <h4>Platform</h4>
            <a href="<?= $prefix ?>about.php">About</a>
            <?php if ($loggedIn): ?>
            <a href="<?= $prefix ?>resources.php">Resources</a>
            <a href="<?= $prefix ?>announcements.php">Announcements</a>
            <a href="<?= $prefix ?>calendar.php">Calendar</a>
            <?php else: ?>
            <a href="<?= $prefix ?>login.php">Student portal</a>
            <?php endif; ?>
        </div>
        <div>
            <h4>Account</h4>
            <a href="<?= $prefix ?>login.php">Sign in</a>
            <a href="<?= $prefix ?>register.php">Register</a>
            <a href="<?= $prefix ?>contact.php">Contact</a>
        </div>
        <div>
            <h4>Support</h4>
            <a href="<?= $prefix ?>contact.php">IT Helpdesk</a>
            <a href="mailto:admin@novaai.com">admin@novaai.com</a>
        </div>
    </div>
    <div class="footer-bottom">Nova AI · <?= date('Y') ?></div>
</footer>
    <?php
}

function render_nav_script(string $assetPrefix = '../'): void {
    static $loaded = false;
    if ($loaded) return;
    $loaded = true;
    echo '<script src="' . htmlspecialchars($assetPrefix, ENT_QUOTES, 'UTF-8') . 'assets/js/nav.js"></script>';
}

function page_open(string $title, string $bodyClass = 'page-shell', bool $authPage = false): void {
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?> — Nova AI</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<?php if ($authPage): ?><link rel="stylesheet" href="../assets/css/auth.css"><?php endif; ?>
</head>
<body class="<?= htmlspecialchars($bodyClass, ENT_QUOTES, 'UTF-8') ?><?= $authPage ? ' auth-page' : '' ?>">
    <?php
}

function admin_page_open(string $title): void {
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?> — Nova AI Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body class="page-shell">
    <?php
}

function page_close(string $footerPrefix = '', string $assetPrefix = '../'): void {
    $loggedIn = isset($_SESSION['user_id']);
    render_nav_script($assetPrefix);
    if ($loggedIn) {
        echo '<footer class="auth-footer">Nova AI · ' . date('Y') . '</footer>';
    } else {
        render_site_footer($footerPrefix, false);
    }
    echo '</body></html>';
}

function auth_page_close(): void {
    render_nav_script('../');
    echo '<footer class="auth-footer">Nova AI · ' . date('Y') . '</footer></body></html>';
}

function admin_page_close(): void {
    render_nav_script('../../');
    render_site_footer('../', true);
    echo '</body></html>';
}
