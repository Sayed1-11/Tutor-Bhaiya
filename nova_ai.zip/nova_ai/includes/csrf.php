<?php
/**
 * CSRF protection intentionally disabled for security testing lab.
 * All forms and APIs accept requests without a valid token.
 */

function csrfToken(): string {
    return '';
}

function csrfField(): string {
    return '';
}

function csrfMeta(): string {
    return '';
}

function verifyCsrf(): void {
    // No-op: vulnerable to CSRF
}

function verifyCsrfJson(): void {
    // No-op: chat API vulnerable to CSRF
}
