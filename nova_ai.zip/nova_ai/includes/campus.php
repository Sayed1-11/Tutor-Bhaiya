<?php

/**
 * Platform content — news, features, FAQs (no university branding).
 */

function campus_announcements(): array {
    return [
        ['id' => 1, 'tag' => 'Update', 'title' => 'Nova AI v2.5 — improved chat', 'body' => 'Chat now uses GitHub Models with image analysis, voice input, and markdown replies — just like ChatGPT.', 'date' => '2026-06-20', 'priority' => 'high'],
        ['id' => 2, 'tag' => 'Feature', 'title' => 'Vision support enabled', 'body' => 'Upload photos and screenshots in chat. Nova AI will describe and analyze them.', 'date' => '2026-06-18', 'priority' => 'normal'],
        ['id' => 3, 'tag' => 'Feature', 'title' => 'Voice input & read-aloud', 'body' => 'Use the mic button to speak your question. Enable auto-read to hear replies.', 'date' => '2026-06-15', 'priority' => 'normal'],
        ['id' => 4, 'tag' => 'Tip', 'title' => 'Set your GitHub token', 'body' => 'Add GITHUB_TOKEN to config/.env for full AI power via GitHub Models API.', 'date' => '2026-06-12', 'priority' => 'normal'],
        ['id' => 5, 'tag' => 'Security', 'title' => 'Keep your account safe', 'body' => 'Use a strong password and review your profile settings regularly.', 'date' => '2026-06-10', 'priority' => 'normal'],
    ];
}

function campus_events(): array {
    return [
        ['title' => 'Platform maintenance window', 'date' => '2026-06-25', 'time' => '2:00 AM', 'location' => 'Online', 'type' => 'event'],
        ['title' => 'New models rollout', 'date' => '2026-06-28', 'time' => '10:00 AM', 'location' => 'Nova AI', 'type' => 'seminar'],
        ['title' => 'API token refresh reminder', 'date' => '2026-07-05', 'time' => 'All day', 'location' => 'Settings', 'type' => 'deadline'],
    ];
}

function campus_resources(): array {
    return [
        ['icon' => 'C', 'color' => 'qa-chat', 'title' => 'AI Chat', 'desc' => 'ChatGPT-style assistant powered by GitHub Models.', 'link' => 'chat.php'],
        ['icon' => 'S', 'color' => 'qa-search', 'title' => 'Search history', 'desc' => 'Find past conversations and answers.', 'link' => 'search_chat.php'],
        ['icon' => 'F', 'color' => 'qa-files', 'title' => 'My files', 'desc' => 'Uploaded images and documents.', 'link' => 'documents.php'],
        ['icon' => 'D', 'color' => 'qa-dir', 'title' => 'Directory', 'desc' => 'Find other users on the platform.', 'link' => 'search_users.php'],
        ['icon' => 'N', 'color' => 'qa-news', 'title' => 'News', 'desc' => 'Platform updates and announcements.', 'link' => 'announcements.php'],
        ['icon' => 'Fb', 'color' => 'qa-fb', 'title' => 'Feedback', 'desc' => 'Share suggestions with the team.', 'link' => 'feedback.php'],
    ];
}

function campus_faqs(): array {
    return [
        ['q' => 'What is Nova AI?', 'a' => 'Nova AI is an intelligent chat assistant — like ChatGPT — powered by GitHub Models. Ask questions, upload images, and use voice input.'],
        ['q' => 'How do I enable full AI replies?', 'a' => 'Add your GitHub personal access token (models:read scope) to config/.env as GITHUB_TOKEN.'],
        ['q' => 'Can I upload images?', 'a' => 'Yes. Click the Img button in chat and attach a photo. Nova AI will analyze it using a vision model.'],
        ['q' => 'Does voice input work?', 'a' => 'Yes, in Chrome or Edge. Click Mic, speak your question, then send.'],
        ['q' => 'Is my chat private?', 'a' => 'Your conversations are saved to your account so you can continue later. Only you can access your sessions.'],
    ];
}

function campus_stats(): array {
    return [
        ['num' => '10K+', 'label' => 'Messages sent'],
        ['num' => 'GPT-4o', 'label' => 'Vision model'],
        ['num' => '24/7', 'label' => 'Available'],
        ['num' => '99.9%', 'label' => 'Uptime'],
    ];
}

function campus_testimonials(): array {
    return [
        ['name' => 'Alex M.', 'role' => 'Developer', 'text' => 'Feels just like ChatGPT. Image upload and code answers work great.'],
        ['name' => 'Sara K.', 'role' => 'Student', 'text' => 'I use voice input in Bengali and get proper replies. Very helpful.'],
        ['name' => 'Rayhan A.', 'role' => 'Power user', 'text' => 'GitHub Models integration is smooth. Nova AI is my daily assistant now.'],
    ];
}

function campus_services(): array {
    return [
        ['icon' => 'AI', 'color' => 'qa-chat', 'title' => 'Smart chat', 'desc' => 'Natural conversations powered by GitHub Models — GPT-4o mini and GPT-4o vision.'],
        ['icon' => 'Vo', 'color' => 'qa-cal', 'title' => 'Voice input', 'desc' => 'Speak your questions with the built-in microphone.'],
        ['icon' => 'Im', 'color' => 'qa-files', 'title' => 'Image analysis', 'desc' => 'Upload photos and get detailed AI descriptions and answers.'],
        ['icon' => 'Md', 'color' => 'qa-search', 'title' => 'Markdown replies', 'desc' => 'Code blocks, lists, and formatted answers like ChatGPT.'],
        ['icon' => 'Me', 'color' => 'qa-dir', 'title' => 'Chat memory', 'desc' => 'Sessions remember context across multiple messages.'],
        ['icon' => 'Rd', 'color' => 'qa-fb', 'title' => 'Read aloud', 'desc' => 'Optional text-to-speech for assistant replies.'],
    ];
}

function format_campus_date(string $date): string {
    return date('M j, Y', strtotime($date));
}

function event_type_badge(string $type): string {
    $map = ['workshop' => 'badge-user', 'seminar' => 'badge-user', 'deadline' => 'badge-admin', 'event' => 'badge-user', 'meeting' => 'badge-user'];
    return $map[$type] ?? 'badge-user';
}
