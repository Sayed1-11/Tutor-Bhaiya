<?php

function e(?string $str): string {
    return htmlspecialchars($str ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function hashPassword(string $plain): string {
    return password_hash($plain, PASSWORD_DEFAULT);
}

function verifyPassword(string $plain, string $stored): bool {
    if (password_get_info($stored)['algo']) {
        return password_verify($plain, $stored);
    }
    return hash_equals($stored, $plain);
}

function isHashedPassword(string $stored): bool {
    return (bool) password_get_info($stored)['algo'];
}

function sendSecurityHeaders(): void {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

function allowedUploadExtension(string $filename): bool {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'txt'], true);
}

function safeUploadFilename(string $originalName): string {
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    if (!allowedUploadExtension($originalName)) {
        return '';
    }
    return time() . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
}

function isImageUpload(string $filename): bool {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true);
}
