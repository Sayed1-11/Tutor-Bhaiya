<?php

$envFile = __DIR__ . '/../config/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($key, $val) = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($val));
        }
    }
}

$host   = getenv('DB_HOST') ?: 'localhost';
$dbname = getenv('DB_NAME') ?: 'nova_ai';
$user   = getenv('DB_USER') ?: 'root';
$pass   = getenv('DB_PASS') ?: '';

$conn = mysqli_connect($host, $user, $pass, $dbname);
if (!$conn) {
    die("Service temporarily unavailable.");
}
mysqli_set_charset($conn, 'utf8mb4');
mysqli_report(MYSQLI_REPORT_OFF);

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Service temporarily unavailable.");
}

function getClientIP() {
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}

function ensureFeedbackGuestColumns(mysqli $conn): void {
    static $checked = false;
    if ($checked) {
        return;
    }
    $checked = true;
    $res = mysqli_query($conn, "SHOW COLUMNS FROM feedback LIKE 'guest_name'");
    if ($res && mysqli_num_rows($res) === 0) {
        mysqli_query($conn, 'ALTER TABLE feedback MODIFY user_id INT NULL');
        mysqli_query($conn, 'ALTER TABLE feedback ADD COLUMN guest_name VARCHAR(255) NULL AFTER user_id');
        mysqli_query($conn, 'ALTER TABLE feedback ADD COLUMN guest_email VARCHAR(255) NULL AFTER guest_name');
    }
}
