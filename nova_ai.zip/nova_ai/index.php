<?php
require_once 'includes/session.php';
require_once 'includes/db.php';
require_once 'includes/app_layout.php';
require_once 'includes/campus.php';

$loggedIn = isset($_SESSION['user_id']);
$stats = campus_stats();
$services = campus_services();
$testimonials = campus_testimonials();
$faqs = campus_faqs();
$announcements = array_slice(campus_announcements(), 0, 3);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nova AI — Intelligent Assistant</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/landing.css">
</head>
<body class="page-shell landing-page">
<?php render_public_navbar($loggedIn); ?>

<section class="landing-hero">
    <div class="landing-wrap">
        <span class="landing-badge">Powered by GitHub Models</span>
        <h1>Your AI assistant, like ChatGPT</h1>
        <p>Ask anything, upload images, use voice — Nova AI gives smart, natural replies using GitHub Models API.</p>
        <div class="landing-cta">
            <?php if ($loggedIn): ?>
            <a href="pages/chat.php" class="btn">Open chat</a>
            <a href="pages/dashboard.php" class="btn btn-outline">Dashboard</a>
            <?php else: ?>
            <a href="pages/register.php" class="btn">Get started free</a>
            <a href="pages/login.php" class="btn btn-outline">Sign in</a>
            <a href="pages/feedback.php" class="btn btn-outline">Feedback</a>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="landing-stats">
    <div class="landing-wrap">
        <?php foreach ($stats as $s): ?>
        <div class="landing-stat">
            <div class="num"><?= e($s['num']) ?></div>
            <div class="label"><?= e($s['label']) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="landing-section">
    <div class="landing-wrap">
        <div class="landing-head">
            <h2>What Nova AI can do</h2>
            <p>Everything you expect from a modern AI assistant.</p>
        </div>
        <div class="landing-features">
            <?php foreach ($services as $svc): ?>
            <article class="landing-feature">
                <div class="fc-icon qa-icon <?= e($svc['color']) ?>"><?= e($svc['icon']) ?></div>
                <h3><?= e($svc['title']) ?></h3>
                <p><?= e($svc['desc']) ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="landing-section landing-section--alt">
    <div class="landing-wrap">
        <div class="landing-head">
            <h2>How it works</h2>
            <p>Three steps to start chatting.</p>
        </div>
        <div class="landing-steps">
            <div class="landing-step">
                <div class="landing-step-num">1</div>
                <h4>Create account</h4>
                <p>Sign up in seconds with email and username.</p>
            </div>
            <div class="landing-step">
                <div class="landing-step-num">2</div>
                <h4>Open chat</h4>
                <p>Type, speak, or attach an image to your message.</p>
            </div>
            <div class="landing-step">
                <div class="landing-step-num">3</div>
                <h4>Get answers</h4>
                <p>Nova AI replies with helpful, formatted responses.</p>
            </div>
        </div>
    </div>
</section>

<section class="landing-section">
    <div class="landing-wrap">
        <div class="landing-head">
            <h2>Latest updates</h2>
        </div>
        <div class="landing-announcements">
            <?php foreach ($announcements as $a): ?>
            <article class="announcement-card <?= $a['priority'] === 'high' ? 'priority-high' : '' ?>">
                <div class="meta"><span class="tag-pill"><?= e($a['tag']) ?></span><span><?= format_campus_date($a['date']) ?></span></div>
                <h3><?= e($a['title']) ?></h3>
                <p><?= e($a['body']) ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="landing-section landing-section--alt">
    <div class="landing-wrap">
        <div class="landing-head">
            <h2>What users say</h2>
        </div>
        <div class="landing-testimonials">
            <?php foreach ($testimonials as $t): ?>
            <div class="testimonial-card">
                <p>"<?= e($t['text']) ?>"</p>
                <div class="author"><?= e($t['name']) ?></div>
                <div class="role"><?= e($t['role']) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="landing-section">
    <div class="landing-wrap">
        <div class="landing-head"><h2>FAQ</h2></div>
        <div class="faq-list">
            <?php foreach ($faqs as $f): ?>
            <div class="faq-item">
                <h4><?= e($f['q']) ?></h4>
                <p><?= e($f['a']) ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="landing-cta-block">
    <h2>Ready to chat?</h2>
    <p>Start talking to Nova AI — it's free to try.</p>
    <a href="<?= $loggedIn ? 'pages/chat.php' : 'pages/register.php' ?>" class="btn"><?= $loggedIn ? 'Open chat' : 'Create account' ?></a>
</section>

<?php render_site_footer('pages/', $loggedIn); ?>
<script src="assets/js/nav.js"></script>
</body>
</html>
