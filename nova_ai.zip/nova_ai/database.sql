-- =============================================
-- Nova AI — Database Schema
-- =============================================

CREATE DATABASE IF NOT EXISTS nova_ai;
USE nova_ai;

DROP TABLE IF EXISTS activity_log;
DROP TABLE IF EXISTS uploads;
DROP TABLE IF EXISTS user_profiles;
DROP TABLE IF EXISTS chat_history;
DROP TABLE IF EXISTS chat_sessions;
DROP TABLE IF EXISTS password_resets;
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS user_sessions;
DROP TABLE IF EXISTS admin_settings;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS feedback;
DROP TABLE IF EXISTS chatbot_logs;
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS users;

-- 1. USERS (Notebook + PII fields)
CREATE TABLE users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    full_name   VARCHAR(100),
    username    VARCHAR(50) UNIQUE,
    email       VARCHAR(100) UNIQUE,
    phone       VARCHAR(20),
    address     TEXT,
    date_of_birth DATE,
    nid_number  VARCHAR(20),
    password    VARCHAR(255),
    role        ENUM('user','admin') DEFAULT 'user',
    profile_photo VARCHAR(255),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. CHAT_MESSAGES (Notebook)
CREATE TABLE chat_messages (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT,
    session_id   INT DEFAULT NULL,
    user_message TEXT,
    bot_response TEXT,
    has_image    TINYINT DEFAULT 0,
    image_path   VARCHAR(500),
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 3. CHATBOT_LOGS (Notebook: chat_bot_logs)
CREATE TABLE chatbot_logs (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,
    activity   VARCHAR(255),
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 4. FEEDBACK (Notebook)
CREATE TABLE feedback (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT NULL,
    guest_name    VARCHAR(255) NULL,
    guest_email   VARCHAR(255) NULL,
    feedback_text TEXT,
    rating        INT DEFAULT 5,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 5. NOTIFICATIONS (Notebook)
CREATE TABLE notifications (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,
    title      VARCHAR(255),
    message    TEXT,
    is_read    TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 6. ADMIN_SETTINGS (Notebook)
CREATE TABLE admin_settings (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    site_name  VARCHAR(100),
    email      VARCHAR(100),
    api_key    VARCHAR(255),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 7. USER_SESSIONS (Notebook)
CREATE TABLE user_sessions (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,
    token      VARCHAR(255),
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 8. CHAT SESSIONS (AI memory)
CREATE TABLE chat_sessions (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,
    title      VARCHAR(255) DEFAULT 'New Chat',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 9. CHAT HISTORY (AI context)
CREATE TABLE chat_history (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT,
    user_id    INT,
    role       ENUM('user','assistant') DEFAULT 'user',
    content    TEXT,
    has_image  TINYINT DEFAULT 0,
    image_path VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 10. USER PROFILES (Extra PII)
CREATE TABLE user_profiles (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    user_id           INT UNIQUE,
    bio               TEXT,
    emergency_contact VARCHAR(20),
    blood_group       VARCHAR(5),
    university_id     VARCHAR(50),
    department        VARCHAR(100),
    semester          VARCHAR(20),
    updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 11. UPLOADS
CREATE TABLE uploads (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT,
    filename      VARCHAR(255),
    original_name VARCHAR(255),
    file_type     VARCHAR(50),
    uploaded_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 12. ACTIVITY LOG
CREATE TABLE activity_log (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,
    action     VARCHAR(255),
    details    TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 13. CONTACT MESSAGES
CREATE TABLE contact_messages (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100),
    email      VARCHAR(100),
    phone      VARCHAR(20),
    message    TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 14. PASSWORD RESETS
CREATE TABLE password_resets (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,
    token      VARCHAR(255),
    expires_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =============================================
-- SEED DATA
-- =============================================

INSERT INTO users (full_name, username, email, phone, address, date_of_birth, nid_number, password, role) VALUES
('Admin User',   'admin',  'admin@novaai.com',  '01711111111', 'Dhaka, Bangladesh',    '1990-01-01', '1234567890', 'admin123',  'admin'),
('Rayhan Ahmed', 'rayhan', 'rayhan@amr.edu.bd', '01722222222', 'Chittagong, BD',       '2002-05-15', '9876543210', 'rayhan123', 'user'),
('Fatima Khan',  'fatima', 'fatima@amr.edu.bd', '01733333333', 'Sylhet, Bangladesh',   '2001-08-20', '5555555555', 'fatima123', 'user'),
('Karim Hassan', 'karim',  'karim@gmail.com',   '01744444444', 'Rajshahi, Bangladesh', '2003-03-10', '1111111111', 'karim123',  'user');

INSERT INTO user_profiles (user_id, bio, emergency_contact, blood_group, university_id, department, semester) VALUES
(1, 'System Administrator', '01799999999', 'O+',  'AMR-2020-001', 'CSE', 'Graduated'),
(2, 'AI Project Developer',  '01888888888', 'A+',  'AMR-2022-045', 'CSE', '6th'),
(3, 'Cyber Security Student','01977777777', 'B+',  'AMR-2022-067', 'CSE', '6th'),
(4, 'Regular User',           '01666666666', 'AB+', 'AMR-2023-012', 'EEE', '4th');

INSERT INTO admin_settings (site_name, email, api_key) VALUES
('Nova AI', 'admin@novaai.com', 'ghp_secret_api_key_DO_NOT_EXPOSE_12345');

INSERT INTO notifications (user_id, title, message) VALUES
(2, 'Welcome!', 'Welcome to Nova AI Chatbot System'),
(2, 'Security Alert', 'Your profile was updated successfully'),
(3, 'New Feature', 'Voice chat is now available!'),
(4, 'Reminder', 'Complete your profile information');

INSERT INTO chat_sessions (user_id, title) VALUES
(2, 'AI Project Discussion'),
(3, 'Cyber Security Questions');

INSERT INTO chatbot_logs (user_id, activity, ip_address) VALUES
(2, 'Logged in', '127.0.0.1'),
(2, 'Started chat session', '127.0.0.1'),
(3, 'Logged in', '127.0.0.1'),
(1, 'Admin dashboard accessed', '127.0.0.1');
