(function () {
    function initNav() {
        document.querySelectorAll('.site-nav').forEach(function (nav) {
            var toggle = nav.querySelector('.nav-toggle');
            var drawer = nav.querySelector('.nav-drawer');
            var overlay = nav.querySelector('.nav-overlay');
            if (!toggle || !drawer) return;

            function open() {
                nav.classList.add('nav-open');
                toggle.setAttribute('aria-expanded', 'true');
                document.body.style.overflow = 'hidden';
            }

            function close() {
                nav.classList.remove('nav-open');
                toggle.setAttribute('aria-expanded', 'false');
                document.body.style.overflow = '';
            }

            toggle.addEventListener('click', function () {
                nav.classList.contains('nav-open') ? close() : open();
            });

            if (overlay) overlay.addEventListener('click', close);

            drawer.querySelectorAll('a').forEach(function (link) {
                link.addEventListener('click', close);
            });

            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') close();
            });
        });

        document.querySelectorAll('.nav-dropdown').forEach(function (dd) {
            var btn = dd.querySelector('.nav-dropdown-btn');
            var menu = dd.querySelector('.nav-dropdown-menu');
            if (!btn) return;

            btn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var isOpen = dd.classList.contains('open');
                document.querySelectorAll('.nav-dropdown.open').forEach(function (d) {
                    d.classList.remove('open');
                });
                if (!isOpen) dd.classList.add('open');
            });

            if (menu) {
                menu.addEventListener('click', function (e) {
                    e.stopPropagation();
                });
            }
        });

        document.addEventListener('click', function (e) {
            if (e.target.closest('.nav-dropdown')) return;
            document.querySelectorAll('.nav-dropdown.open').forEach(function (d) {
                d.classList.remove('open');
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initNav);
    } else {
        initNav();
    }
})();
