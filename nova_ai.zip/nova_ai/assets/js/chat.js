// Nova AI — Chat (GitHub Models, voice, image, markdown)

let currentSessionId = null;
let isRecording = false;
let recognition = null;
let isSending = false;

function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.content : '';
}

function chatApiUrl() {
    return window.NOVA_CHAT_API || 'api/chat_api.php';
}

async function chatApiPost(formData) {
    return fetch(chatApiUrl(), {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
    });
}

function csrfHeaders() {
    return { 'X-CSRF-Token': getCsrfToken() };
}

function escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
}

function renderMarkdown(text) {
    const safe = text == null ? '' : String(text);
    if (typeof marked !== 'undefined') {
        try {
            marked.setOptions({ breaks: true, gfm: true });
            return marked.parse(safe);
        } catch {
            return '<p>' + escapeHtml(safe).replace(/\n/g, '<br>') + '</p>';
        }
    }
    return '<p>' + escapeHtml(safe).replace(/\n/g, '<br>') + '</p>';
}

function autoResizeTextarea(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 160) + 'px';
}

// Speech recognition — Bengali + English
if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.lang = 'bn-BD';
    recognition.interimResults = false;
    recognition.continuous = false;
    recognition.onresult = (e) => {
        const input = document.getElementById('messageInput');
        input.value = (input.value ? input.value + ' ' : '') + e.results[0][0].transcript;
        autoResizeTextarea(input);
    };
    recognition.onend = () => {
        isRecording = false;
        const btn = document.getElementById('voiceBtn');
        if (btn) btn.classList.remove('recording');
    };
    recognition.onerror = () => {
        isRecording = false;
        const btn = document.getElementById('voiceBtn');
        if (btn) btn.classList.remove('recording');
    };
}

function toggleVoice() {
    if (!recognition) {
        alert('Voice input needs Chrome or Edge.');
        return;
    }
    const btn = document.getElementById('voiceBtn');
    if (isRecording) {
        recognition.stop();
    } else {
        recognition.start();
        isRecording = true;
        btn.classList.add('recording');
    }
}

function clearWelcome() {
    const w = document.getElementById('chatWelcome');
    if (w) w.remove();
}

function addMessage(role, content, imagePath) {
    clearWelcome();
    const inner = document.getElementById('chatMessagesInner');
    const row = document.createElement('div');
    row.className = 'msg-row ' + (role === 'user' ? 'user' : '');

    const avatar = document.createElement('div');
    avatar.className = 'msg-avatar ' + (role === 'user' ? 'user' : 'bot');
    avatar.textContent = role === 'user' ? 'U' : 'AI';

    const body = document.createElement('div');
    body.className = 'msg-body' + (role === 'user' ? ' user' : '');

    const bubble = document.createElement('div');
    bubble.className = 'msg-content';
    if (role === 'user') {
        bubble.innerHTML = escapeHtml(content).replace(/\n/g, '<br>');
    } else {
        bubble.innerHTML = renderMarkdown(content);
    }

    if (imagePath) {
        const img = document.createElement('img');
        img.src = '../../' + imagePath;
        img.alt = 'Uploaded image';
        bubble.appendChild(img);
    }

    body.appendChild(bubble);
    row.appendChild(avatar);
    row.appendChild(body);
    inner.appendChild(row);

    const area = document.getElementById('chatArea');
    area.scrollTop = area.scrollHeight;
}

function showTyping() {
    clearWelcome();
    const inner = document.getElementById('chatMessagesInner');
    const row = document.createElement('div');
    row.id = 'typingIndicator';
    row.className = 'msg-row';
    row.innerHTML = '<div class="msg-avatar bot">AI</div><div class="msg-body"><div class="msg-content"><div class="typing-dots"><span></span><span></span><span></span></div></div></div>';
    inner.appendChild(row);
    document.getElementById('chatArea').scrollTop = document.getElementById('chatArea').scrollHeight;
}

function hideTyping() {
    const el = document.getElementById('typingIndicator');
    if (el) el.remove();
}

async function sendMessage(e) {
    if (e) e.preventDefault();
    if (isSending) return;

    const input = document.getElementById('messageInput');
    const msg = input.value.trim();
    const imageInput = document.getElementById('imageInput');
    const hasFile = imageInput.files && imageInput.files[0];

    if (!msg && !hasFile) return;

    isSending = true;
    document.getElementById('sendBtn').disabled = true;

    const formData = new FormData();
    formData.append('action', 'chat');
    formData.append('message', msg);
    formData.append('session_id', currentSessionId || '0');
    formData.append('csrf_token', getCsrfToken());
    if (hasFile) formData.append('image', imageInput.files[0]);

    const previewPath = hasFile ? URL.createObjectURL(imageInput.files[0]) : null;
    addMessage('user', msg || '(Image attached)', null);
    if (previewPath) {
        const lastContent = document.querySelector('.msg-row.user:last-child .msg-content');
        if (lastContent) {
            const img = document.createElement('img');
            img.src = previewPath;
            lastContent.appendChild(img);
        }
    }

    input.value = '';
    input.style.height = 'auto';
    imageInput.value = '';
    document.getElementById('imagePreview').innerHTML = '';
    showTyping();

    let responseDelivered = false;

    try {
        const res = await chatApiPost(formData);
        if (!res.ok) {
            hideTyping();
            addMessage('assistant', 'Server error (' + res.status + '). Please try again.');
            return;
        }

        const text = await res.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch {
            hideTyping();
            console.error('Invalid JSON from chat API:', text.slice(0, 200));
            addMessage('assistant', 'Server error. Please try again.');
            return;
        }
        hideTyping();

        if (data.error) {
            addMessage('assistant', data.error);
            responseDelivered = true;
            return;
        }

        currentSessionId = data.session_id;
        responseDelivered = true;
        addMessage('assistant', data.bot_response || '', data.image_path || null);

        if (!data.ai_ok && data.ai_error) {
            console.warn('AI API:', data.ai_error);
        }

        try {
            await loadSessions();
        } catch (err) {
            console.warn('Could not refresh session list:', err);
        }
    } catch (err) {
        hideTyping();
        console.error('Chat send error:', err);
        if (!responseDelivered) {
            addMessage('assistant', 'Connection error. Check your network and try again.');
        }
    } finally {
        isSending = false;
        document.getElementById('sendBtn').disabled = false;
    }
}

function useSuggestion(text) {
    const input = document.getElementById('messageInput');
    input.value = text;
    autoResizeTextarea(input);
    input.focus();
}

async function loadSessions() {
    const formData = new FormData();
    formData.append('action', 'get_sessions');
    formData.append('csrf_token', getCsrfToken());
    const res = await chatApiPost(formData);
    if (!res.ok) return;
    const text = await res.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch {
        console.warn('Invalid JSON loading sessions:', text.slice(0, 120));
        return;
    }
    const list = document.getElementById('sessionList');
    if (!list) return;
    list.innerHTML = '';
    (data.sessions || []).forEach(s => {
            const row = document.createElement('div');
            row.className = 'session-row' + (s.id == currentSessionId ? ' active' : '');

            const item = document.createElement('div');
            item.className = 'session-item';
            item.textContent = s.title || 'Chat ' + s.id;
            item.onclick = () => loadSession(s.id);

            row.appendChild(item);
            list.appendChild(row);
        });
}

async function deleteSession(sessionId) {
    if (!confirm('Delete this chat?')) return;

    const formData = new FormData();
    formData.append('action', 'delete_session');
    formData.append('session_id', sessionId);
    formData.append('csrf_token', getCsrfToken());

    try {
        const res = await chatApiPost(formData);
        const data = await res.json();
        if (data.error) {
            alert(data.error);
            return;
        }
        if (currentSessionId == sessionId) {
            currentSessionId = null;
            document.getElementById('chatMessagesInner').innerHTML = '';
            showWelcome();
        }
        loadSessions();
    } catch {
        alert('Could not delete chat. Try again.');
    }
}

async function loadSession(sessionId) {
    currentSessionId = sessionId;
    const formData = new FormData();
    formData.append('action', 'get_history');
    formData.append('session_id', sessionId);
    formData.append('csrf_token', getCsrfToken());
    const res = await chatApiPost(formData);
    const data = await res.json();

    const inner = document.getElementById('chatMessagesInner');
    inner.innerHTML = '';
    (data.history || []).forEach(h => {
        const role = h.role === 'assistant' ? 'assistant' : 'user';
        addMessage(role, h.content, h.image_path);
    });
    if (!data.history || !data.history.length) showWelcome();
    loadSessions();
}

function showWelcome() {
    const inner = document.getElementById('chatMessagesInner');
    inner.innerHTML = `
    <div class="chat-welcome" id="chatWelcome">
        <div class="chat-welcome-icon">AI</div>
        <h2>How can I help?</h2>
        <p>Ask me anything — I can write, explain, code, and analyze images you upload.</p>
        <div class="chat-suggestions">
            <button type="button" class="chat-suggestion" onclick="useSuggestion('Explain how neural networks work simply')"><strong>Explain a topic</strong>Break down complex ideas</button>
            <button type="button" class="chat-suggestion" onclick="useSuggestion('Write a Python script to read a CSV file')"><strong>Write code</strong>Get working code snippets</button>
            <button type="button" class="chat-suggestion" onclick="useSuggestion('আমাকে একটি ছোট গল্প লেখো')"><strong>বাংলায় চ্যাট</strong>বাংলায় প্রশ্ন করুন</button>
            <button type="button" class="chat-suggestion" onclick="document.getElementById('imageInput').click()"><strong>Upload image</strong>Analyze photos & screenshots</button>
        </div>
    </div>`;
}

async function newSession() {
    currentSessionId = null;
    document.getElementById('chatMessagesInner').innerHTML = '';
    showWelcome();
    loadSessions();
}

function previewImage(input) {
    const preview = document.getElementById('imagePreview');
    preview.innerHTML = '';
    if (input.files[0]) {
        const img = document.createElement('img');
        img.src = URL.createObjectURL(input.files[0]);
        preview.className = 'chat-preview';
        preview.appendChild(img);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadSessions();
    const form = document.getElementById('chatForm');
    const input = document.getElementById('messageInput');

    form.addEventListener('submit', sendMessage);
    input.addEventListener('input', () => autoResizeTextarea(input));
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage(e);
        }
    });

    if (!document.querySelector('.msg-row')) showWelcome();
});
